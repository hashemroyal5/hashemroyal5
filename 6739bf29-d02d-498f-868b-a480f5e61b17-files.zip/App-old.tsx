import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { 
  User, 
  LogOut, 
  Clock, 
  Calendar, 
  Package, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Plus, 
  Printer, 
  Users, 
  Settings, 
  BarChart3, 
  MessageSquare, 
  Bell,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Edit,
  Trash2,
  Store,
  UserPlus,
  Shield,
  Home
} from "lucide-react";

// Types
type UserRole = 'RFS' | 'OC' | 'RM';

interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  name: string;
  regionId?: string;
  restaurantId?: string;
  restaurants?: string[];
  createdAt: Date;
}

interface Region {
  id: string;
  name: string;
  ocId: string;
  restaurantCount: number;
  restaurants: Restaurant[];
}

interface Restaurant {
  id: string;
  name: string;
  regionId: string;
  managerId?: string;
  address: string;
}

type ProductCategory = 'meat' | 'chicken' | 'bakery' | 'vegetables' | 'beverages' | 'condiments' | 'frozen' | 'dairy' | 'mccafe';

interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  color: string;
  defaultShelfLifeHours: number;
  isDailyProduct: boolean;
  requiresThawing: boolean;
  thawTimeHours?: number;
  notes?: string;
  isActive: boolean;
  labelSize: 'small' | 'medium' | 'large';
}

type InventoryStatus = 'fresh' | 'warning' | 'expired';

interface InventoryItem {
  id: string;
  productId: string;
  restaurantId: string;
  quantity: number;
  receivedDate: Date;
  expiryDate: Date;
  status: InventoryStatus;
  batchNumber?: string;
  isDaily: boolean;
  autoRenew?: boolean;
  renewalHours?: number;
}

interface PrintLabel {
  id: string;
  productName: string;
  quantity: number;
  thawDate?: Date;
  useByDate: Date;
  wasteDate: Date;
  restaurantName: string;
  printedAt: Date;
  labelSize: 'small' | 'medium' | 'large';
}

interface Message {
  id: string;
  fromUserId: string;
  toUserId?: string;
  toRole?: UserRole;
  subject: string;
  content: string;
  isRead: boolean;
  createdAt: Date;
  isSystemMessage: boolean;
}

interface Notification {
  id: string;
  userId: string;
  type: 'expiration' | 'system' | 'message';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

// Initial Data
const INITIAL_PRODUCTS: Product[] = [
  // Meat & Chicken
  { id: '1', name: 'BEEF PATTIES 4:1', category: 'meat', color: 'bg-red-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 24, isActive: true, labelSize: 'medium' },
  { id: '2', name: 'CHICKEN NUGGETS', category: 'chicken', color: 'bg-orange-500', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium' },
  { id: '3', name: 'FAJITA CHICKEN', category: 'chicken', color: 'bg-orange-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 18, isActive: true, labelSize: 'medium' },
  { id: '4', name: 'GRILLED CHICKEN', category: 'chicken', color: 'bg-yellow-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium' },
  
  // Bakery
  { id: '5', name: 'BIG MAC BUNS', category: 'bakery', color: 'bg-amber-500', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large' },
  { id: '6', name: 'QUARTER POUNDER BUNS', category: 'bakery', color: 'bg-amber-600', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large' },
  { id: '7', name: 'ENGLISH MUFFIN', category: 'bakery', color: 'bg-yellow-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '8', name: 'TORTILLA', category: 'bakery', color: 'bg-yellow-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  
  // Vegetables & Fresh
  { id: '9', name: 'ICEBERG LETTUCE', category: 'vegetables', color: 'bg-green-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large' },
  { id: '10', name: 'TOMATOES', category: 'vegetables', color: 'bg-red-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '11', name: 'CAESAR SALAD MIX', category: 'vegetables', color: 'bg-green-400', defaultShelfLifeHours: 6, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '12', name: 'FRESH LETTUCE MIX', category: 'vegetables', color: 'bg-green-300', defaultShelfLifeHours: 8, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '13', name: 'RECONSTITUTED ONION', category: 'vegetables', color: 'bg-purple-400', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '14', name: 'DEHYDRATED ONION', category: 'vegetables', color: 'bg-purple-500', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  
  // Frozen Items
  { id: '15', name: 'FRENCH FRIES', category: 'frozen', color: 'bg-yellow-300', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large' },
  { id: '16', name: 'HASH BROWNS', category: 'frozen', color: 'bg-yellow-700', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  
  // Beverages
  { id: '17', name: 'APPLE JUICE', category: 'beverages', color: 'bg-red-300', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '18', name: 'ORANGE JUICE', category: 'beverages', color: 'bg-orange-400', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '19', name: 'COCA-COLA SYRUP', category: 'beverages', color: 'bg-red-700', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '20', name: 'SPRITE SYRUP', category: 'beverages', color: 'bg-green-600', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  
  // Condiments
  { id: '21', name: 'BIG TASTY SAUCE', category: 'condiments', color: 'bg-orange-300', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '22', name: 'PICKLES', category: 'condiments', color: 'bg-green-700', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '23', name: 'VEGETABLE OIL', category: 'condiments', color: 'bg-yellow-200', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large' },
  
  // Dairy
  { id: '24', name: 'MILK 2%', category: 'dairy', color: 'bg-blue-200', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '25', name: 'CHEESE SLICES', category: 'dairy', color: 'bg-yellow-600', defaultShelfLifeHours: 120, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  
  // McCafe
  { id: '26', name: 'COFFEE BEANS', category: 'mccafe', color: 'bg-amber-700', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium' },
  { id: '27', name: 'CARAMEL SAUCE', category: 'mccafe', color: 'bg-amber-600', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' },
  { id: '28', name: 'WHIPPED CREAM', category: 'mccafe', color: 'bg-blue-100', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small' }
];

const INITIAL_USERS: User[] = [
  {
    id: 'rfs-1',
    username: 'RFS',
    password: 'RFS@PC123',
    role: 'RFS',
    name: 'System Administrator',
    createdAt: new Date()
  }
];

// Main App Component
export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  
  // Application State
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [regions, setRegions] = useState<Region[]>([]);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [printQueue, setPrintQueue] = useState<PrintLabel[]>([]);
  
  // UI State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [showCreateUserDialog, setShowCreateUserDialog] = useState(false);
  const [showAddProductDialog, setShowAddProductDialog] = useState(false);
  const [showAddInventoryDialog, setShowAddInventoryDialog] = useState(false);
  const [showPrintDialog, setShowPrintDialog] = useState(false);
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<ProductCategory | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<InventoryStatus | 'all'>('all');

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Check for expiring items and create notifications
  useEffect(() => {
    const checkExpirations = () => {
      const now = new Date();
      const thirtyMinutesFromNow = new Date(now.getTime() + 30 * 60 * 1000);
      
      inventory.forEach(item => {
        if (item.expiryDate <= thirtyMinutesFromNow && item.expiryDate > now) {
          const product = products.find(p => p.id === item.productId);
          if (product) {
            const notificationId = `exp-${item.id}-${item.expiryDate.getTime()}`;
            const existingNotification = notifications.find(n => n.id === notificationId);
            
            if (!existingNotification) {
              const newNotification: Notification = {
                id: notificationId,
                userId: currentUser?.id || '',
                type: 'expiration',
                title: 'Expiration Warning',
                message: `${product.name} expires in 30 minutes!`,
                isRead: false,
                createdAt: now,
                expiresAt: item.expiryDate
              };
              setNotifications(prev => [...prev, newNotification]);
              
              // Auto-print label for expiring items
              if (currentUser?.role === 'RM') {
                printLabel(item.id);
              }
            }
          }
        }
        
        // Update inventory status
        let newStatus: InventoryStatus;
        if (item.expiryDate <= now) {
          newStatus = 'expired';
        } else if (item.expiryDate <= thirtyMinutesFromNow) {
          newStatus = 'warning';
        } else {
          newStatus = 'fresh';
        }
        
        if (item.status !== newStatus) {
          setInventory(prev => prev.map(inv => 
            inv.id === item.id ? { ...inv, status: newStatus } : inv
          ));
        }
      });
    };
    
    const interval = setInterval(checkExpirations, 60000); // Check every minute
    checkExpirations(); // Check immediately
    
    return () => clearInterval(interval);
  }, [inventory, products, notifications, currentUser]);

  // Authentication Functions
  const handleLogin = () => {
    const user = users.find(u => 
      u.username === loginForm.username && u.password === loginForm.password
    );
    
    if (user) {
      setCurrentUser(user);
      setLoginError('');
      setLoginForm({ username: '', password: '' });
    } else {
      setLoginError('Invalid username or password');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab('dashboard');
  };

  // User Management Functions
  const createUser = (userData: Partial<User>) => {
    const newUser: User = {
      id: `user-${Date.now()}`,
      username: userData.username!,
      password: userData.password!,
      role: userData.role!,
      name: userData.name!,
      regionId: userData.regionId,
      restaurantId: userData.restaurantId,
      restaurants: userData.restaurants,
      createdAt: new Date()
    };
    
    setUsers(prev => [...prev, newUser]);
    setShowCreateUserDialog(false);
  };

  // Product Management Functions
  const addProduct = (productData: Partial<Product>) => {
    const newProduct: Product = {
      id: `prod-${Date.now()}`,
      name: productData.name!.toUpperCase(),
      category: productData.category!,
      color: productData.color!,
      defaultShelfLifeHours: productData.defaultShelfLifeHours!,
      isDailyProduct: productData.isDailyProduct || false,
      requiresThawing: productData.requiresThawing || false,
      thawTimeHours: productData.thawTimeHours,
      notes: productData.notes,
      isActive: true,
      labelSize: productData.labelSize || 'medium'
    };
    
    setProducts(prev => [...prev, newProduct]);
    setShowAddProductDialog(false);
  };

  // Inventory Management Functions
  const addInventoryItem = (inventoryData: Partial<InventoryItem>) => {
    const product = products.find(p => p.id === inventoryData.productId);
    if (!product) return;
    
    const receivedDate = inventoryData.receivedDate || new Date();
    const expiryDate = new Date(receivedDate.getTime() + product.defaultShelfLifeHours * 60 * 60 * 1000);
    
    const newItem: InventoryItem = {
      id: `inv-${Date.now()}`,
      productId: inventoryData.productId!,
      restaurantId: currentUser?.restaurantId || restaurants[0]?.id || '',
      quantity: inventoryData.quantity!,
      receivedDate,
      expiryDate,
      status: 'fresh',
      batchNumber: inventoryData.batchNumber,
      isDaily: product.isDailyProduct,
      autoRenew: product.isDailyProduct,
      renewalHours: product.isDailyProduct ? product.defaultShelfLifeHours : undefined
    };
    
    setInventory(prev => [...prev, newItem]);
    setShowAddInventoryDialog(false);
    
    // Auto-print label
    setTimeout(() => printLabel(newItem.id), 500);
  };

  // Printing Functions
  const printLabel = (inventoryItemId: string) => {
    const item = inventory.find(i => i.id === inventoryItemId);
    const product = products.find(p => p.id === item?.productId);
    const restaurant = restaurants.find(r => r.id === item?.restaurantId);
    
    if (!item || !product) return;
    
    const now = new Date();
    const thawDate = product.requiresThawing 
      ? new Date(now.getTime() + (product.thawTimeHours || 0) * 60 * 60 * 1000)
      : undefined;
    const wasteDate = new Date(item.expiryDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours after expiry
    
    const label: PrintLabel = {
      id: `label-${Date.now()}`,
      productName: product.name,
      quantity: item.quantity,
      thawDate,
      useByDate: item.expiryDate,
      wasteDate,
      restaurantName: restaurant?.name || 'McDonald\'s Restaurant',
      printedAt: now,
      labelSize: product.labelSize
    };
    
    setPrintQueue(prev => [...prev, label]);
  };

  // Message Functions
  const sendMessage = (messageData: Partial<Message>) => {
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      fromUserId: currentUser?.id!,
      toUserId: messageData.toUserId,
      toRole: messageData.toRole,
      subject: messageData.subject!,
      content: messageData.content!,
      isRead: false,
      createdAt: new Date(),
      isSystemMessage: false
    };
    
    setMessages(prev => [...prev, newMessage]);
    setShowMessageDialog(false);
  };

  // Helper Functions
  const getCurrentUserRestaurants = () => {
    if (currentUser?.role === 'RFS') {
      return restaurants;
    } else if (currentUser?.role === 'OC') {
      return restaurants.filter(r => r.regionId === currentUser.regionId);
    } else if (currentUser?.role === 'RM') {
      return restaurants.filter(r => r.id === currentUser.restaurantId);
    }
    return [];
  };

  const getCurrentUserInventory = () => {
    const userRestaurants = getCurrentUserRestaurants();
    const restaurantIds = userRestaurants.map(r => r.id);
    return inventory.filter(item => restaurantIds.includes(item.restaurantId));
  };

  const getFilteredProducts = () => {
    let filtered = products.filter(p => p.isActive);
    
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (filterCategory !== 'all') {
      filtered = filtered.filter(p => p.category === filterCategory);
    }
    
    return filtered;
  };

  const getFilteredInventory = () => {
    let filtered = getCurrentUserInventory();
    
    if (searchTerm) {
      const productIds = products
        .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(p => p.id);
      filtered = filtered.filter(item => productIds.includes(item.productId));
    }
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(item => item.status === filterStatus);
    }
    
    return filtered;
  };

  const formatDateTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const getCategoryColor = (category: ProductCategory) => {
    const colors = {
      meat: 'bg-red-500',
      chicken: 'bg-orange-500',
      bakery: 'bg-amber-500',
      vegetables: 'bg-green-500',
      beverages: 'bg-blue-500',
      condiments: 'bg-purple-500',
      frozen: 'bg-cyan-500',
      dairy: 'bg-yellow-500',
      mccafe: 'bg-amber-700'
    };
    return colors[category];
  };

  const getStatusColor = (status: InventoryStatus) => {
    const colors = {
      fresh: 'bg-green-500',
      warning: 'bg-yellow-500',
      expired: 'bg-red-500'
    };
    return colors[status];
  };

  const getUnreadNotifications = () => {
    return notifications.filter(n => !n.isRead && n.userId === currentUser?.id).length;
  };

  const getUnreadMessages = () => {
    return messages.filter(m => 
      !m.isRead && 
      (m.toUserId === currentUser?.id || 
       (m.toRole === currentUser?.role && !m.toUserId))
    ).length;
  };

  // Login Component
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-primary rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-primary-foreground">M</span>
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-primary">McDonald's</CardTitle>
              <CardDescription className="text-base mt-2">
                Inventory Management System
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter your password"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            {loginError && (
              <Alert className="border-destructive bg-destructive/10">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-destructive">
                  {loginError}
                </AlertDescription>
              </Alert>
            )}
            <Button 
              onClick={handleLogin} 
              className="w-full bg-primary hover:bg-primary/90"
              size="lg"
            >
              Sign In
            </Button>
            <div className="text-xs text-muted-foreground text-center space-y-1">
              <p><strong>System Owner (RFS):</strong> RFS / RFS@PC123</p>
              <p><strong>Operations Consultant (OC):</strong> Contact RFS for credentials</p>
              <p><strong>Restaurant Manager (RM):</strong> Contact your OC for credentials</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main Dashboard Component
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white border-b border-border shadow-sm">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-lg font-bold text-primary-foreground">M</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary">McDonald's Inventory</h1>
              <p className="text-sm text-muted-foreground">
                {formatDateTime(currentDateTime)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium">{currentUser.name}</p>
              <p className="text-xs text-muted-foreground">
                {currentUser.role === 'RFS' && 'System Administrator'}
                {currentUser.role === 'OC' && 'Operations Consultant'}
                {currentUser.role === 'RM' && 'Restaurant Manager'}
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-4 w-4" />
                {getUnreadNotifications() > 0 && (
                  <Badge className="absolute -top-2 -right-2 px-1 min-w-[1.25rem] h-5">
                    {getUnreadNotifications()}
                  </Badge>
                )}
              </Button>
              
              <Button variant="ghost" size="sm" className="relative">
                <MessageSquare className="h-4 w-4" />
                {getUnreadMessages() > 0 && (
                  <Badge className="absolute -top-2 -right-2 px-1 min-w-[1.25rem] h-5">
                    {getUnreadMessages()}
                  </Badge>
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex">
        {/* Sidebar Navigation */}
        <aside className="w-64 bg-card border-r border-border h-[calc(100vh-4rem)]">
          <nav className="p-4 space-y-2">
            <Button 
              variant={activeTab === 'dashboard' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('dashboard')}
            >
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
            
            <Button 
              variant={activeTab === 'inventory' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('inventory')}
            >
              <Package className="h-4 w-4 mr-2" />
              Inventory
            </Button>
            
            {currentUser.role === 'RM' && (
              <Button 
                variant={activeTab === 'daily-products' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('daily-products')}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Daily Products
              </Button>
            )}
            
            <Button 
              variant={activeTab === 'printing' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('printing')}
            >
              <Printer className="h-4 w-4 mr-2" />
              Label Printing
            </Button>
            
            <Button 
              variant={activeTab === 'reports' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('reports')}
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Reports
            </Button>
            
            <Button 
              variant={activeTab === 'messages' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('messages')}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
              {getUnreadMessages() > 0 && (
                <Badge className="ml-auto px-1 min-w-[1.25rem] h-5">
                  {getUnreadMessages()}
                </Badge>
              )}
            </Button>
            
            {(currentUser.role === 'RFS' || currentUser.role === 'OC') && (
              <Button 
                variant={activeTab === 'users' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('users')}
              >
                <Users className="h-4 w-4 mr-2" />
                User Management
              </Button>
            )}
            
            {currentUser.role === 'RFS' && (
              <Button 
                variant={activeTab === 'products' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('products')}
              >
                <Package className="h-4 w-4 mr-2" />
                Product Catalog
              </Button>
            )}
            
            <Button 
              variant={activeTab === 'settings' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('settings')}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6 overflow-auto h-[calc(100vh-4rem)]">
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Dashboard</h2>
                <div className="flex space-x-2">
                  {currentUser.role === 'RM' && (
                    <Button onClick={() => setShowAddInventoryDialog(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Inventory
                    </Button>
                  )}
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Package className="h-8 w-8 text-primary" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Total Items</p>
                        <p className="text-2xl font-bold">{getCurrentUserInventory().length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Fresh Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'fresh').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <AlertTriangle className="h-8 w-8 text-yellow-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Warning Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'warning').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <XCircle className="h-8 w-8 text-red-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Expired Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'expired').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity & Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Expiring Soon */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
                      Expiring Soon (30 minutes)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {getCurrentUserInventory()
                        .filter(item => item.status === 'warning')
                        .map(item => {
                          const product = products.find(p => p.id === item.productId);
                          return (
                            <div key={item.id} className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                              <div>
                                <p className="font-medium">{product?.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  Expires: {formatDateTime(item.expiryDate)}
                                </p>
                              </div>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => printLabel(item.id)}
                              >
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          );
                        })
                      }
                      {getCurrentUserInventory().filter(item => item.status === 'warning').length === 0 && (
                        <p className="text-muted-foreground text-center py-4">No items expiring soon</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Notifications */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bell className="h-5 w-5 mr-2" />
                      Recent Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {notifications
                        .filter(n => n.userId === currentUser.id)
                        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
                        .slice(0, 5)
                        .map(notification => (
                          <div key={notification.id} className="p-2 bg-muted/50 rounded">
                            <p className="font-medium text-sm">{notification.title}</p>
                            <p className="text-xs text-muted-foreground">{notification.message}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatDateTime(notification.createdAt)}
                            </p>
                          </div>
                        ))
                      }
                      {notifications.filter(n => n.userId === currentUser.id).length === 0 && (
                        <p className="text-muted-foreground text-center py-4">No notifications</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Inventory Tab */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Inventory Management</h2>
                {currentUser.role === 'RM' && (
                  <Button onClick={() => setShowAddInventoryDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                )}
              </div>

              {/* Search and Filters */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as any)}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="fresh">Fresh</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Inventory Table */}
              <Card>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Received</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getFilteredInventory().map(item => {
                        const product = products.find(p => p.id === item.productId);
                        return (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <div className={`w-3 h-3 rounded-full ${product?.color || 'bg-gray-400'}`} />
                                <span className="font-medium">{product?.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={getCategoryColor(product?.category || 'meat')}>
                                {product?.category}
                              </Badge>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{formatDateTime(item.receivedDate)}</TableCell>
                            <TableCell>{formatDateTime(item.expiryDate)}</TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(item.status)}>
                                {item.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-1">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => printLabel(item.id)}
                                >
                                  <Printer className="h-4 w-4" />
                                </Button>
                                {currentUser.role === 'RM' && (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      setInventory(prev => prev.filter(i => i.id !== item.id));
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  
                  {getFilteredInventory().length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No inventory items found
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Other tabs placeholder */}
          {(activeTab !== 'dashboard' && activeTab !== 'inventory') && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold capitalize">{activeTab.replace('-', ' ')}</h2>
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">
                    {activeTab.charAt(0).toUpperCase() + activeTab.slice(1).replace('-', ' ')} functionality is being implemented.
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    This section will include comprehensive features for {activeTab.replace('-', ' ')} management.
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>

      {/* Add Inventory Dialog */}
      <Dialog open={showAddInventoryDialog} onOpenChange={setShowAddInventoryDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Inventory Item</DialogTitle>
            <DialogDescription>
              Add a new item to your restaurant's inventory
            </DialogDescription>
          </DialogHeader>
          
          <AddInventoryForm 
            products={products.filter(p => p.isActive)}
            onSubmit={addInventoryItem}
            onCancel={() => setShowAddInventoryDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Add Inventory Form Component
function AddInventoryForm({ products, onSubmit, onCancel }: {
  products: Product[];
  onSubmit: (data: Partial<InventoryItem>) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState({
    productId: '',
    quantity: 1,
    batchNumber: ''
  });

  const handleSubmit = () => {
    if (!formData.productId) return;
    
    onSubmit({
      productId: formData.productId,
      quantity: formData.quantity,
      batchNumber: formData.batchNumber || undefined,
      receivedDate: new Date()
    });
    
    setFormData({ productId: '', quantity: 1, batchNumber: '' });
  };

  const selectedProduct = products.find(p => p.id === formData.productId);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="product">Product</Label>
        <Select value={formData.productId} onValueChange={(value) => setFormData(prev => ({ ...prev, productId: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select a product" />
          </SelectTrigger>
          <SelectContent>
            {products.map(product => (
              <SelectItem key={product.id} value={product.id}>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${product.color}`} />
                  <span>{product.name}</span>
                  <Badge variant="outline" className="ml-2">{product.category}</Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedProduct && (
        <div className="p-3 bg-muted/50 rounded">
          <p className="text-sm font-medium">Product Information:</p>
          <p className="text-xs text-muted-foreground">Shelf Life: {selectedProduct.defaultShelfLifeHours} hours</p>
          {selectedProduct.requiresThawing && (
            <p className="text-xs text-muted-foreground">Requires thawing: {selectedProduct.thawTimeHours} hours</p>
          )}
          {selectedProduct.isDailyProduct && (
            <p className="text-xs text-yellow-600">Daily Product - Auto-renewal enabled</p>
          )}
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="quantity">Quantity</Label>
        <Input
          id="quantity"
          type="number"
          min="1"
          value={formData.quantity}
          onChange={(e) => setFormData(prev => ({ ...prev, quantity: parseInt(e.target.value) || 1 }))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="batch">Batch Number (Optional)</Label>
        <Input
          id="batch"
          type="text"
          value={formData.batchNumber}
          onChange={(e) => setFormData(prev => ({ ...prev, batchNumber: e.target.value }))}
          placeholder="Enter batch number"
        />
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={!formData.productId}>
          Add Item
        </Button>
      </DialogFooter>
    </div>
  );
}