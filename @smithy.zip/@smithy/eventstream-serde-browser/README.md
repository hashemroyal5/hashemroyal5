# @smithy/eventstream-serde-browser

[![NPM version](https://img.shields.io/npm/v/@smithy/eventstream-serde-browser/latest.svg)](https://www.npmjs.com/package/@smithy/eventstream-serde-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/eventstream-serde-browser.svg)](https://www.npmjs.com/package/@smithy/eventstream-serde-browser)

> An internal package

## Usage

You probably shouldn't, at least directly.
