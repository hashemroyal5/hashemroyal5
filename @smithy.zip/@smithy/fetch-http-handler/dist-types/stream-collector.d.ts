import { StreamCollector } from "@smithy/types";
export declare const streamCollector: StreamCollector;
