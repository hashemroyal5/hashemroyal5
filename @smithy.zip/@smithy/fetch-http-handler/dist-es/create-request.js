export function createRequest(url, requestOptions) {
    return new Request(url, requestOptions);
}
