# @smithy/config-resolver

[![NPM version](https://img.shields.io/npm/v/@smithy/config-resolver/latest.svg)](https://www.npmjs.com/package/@smithy/config-resolver)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/config-resolver.svg)](https://www.npmjs.com/package/@smithy/config-resolver)

> An internal package

## Usage

You probably shouldn't, at least directly.
