# @smithy/util-waiter

[![NPM version](https://img.shields.io/npm/v/@smithy/util-waiter/latest.svg)](https://www.npmjs.com/package/@smithy/util-waiter)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-waiter.svg)](https://www.npmjs.com/package/@smithy/util-waiter)

> An internal package

## Usage

You probably shouldn't, at least directly.
