import { HandlerExecutionContext } from "@smithy/types";
/**
 * @internal
 */
export declare const getSmithyContext: (context: HandlerExecutionContext) => Record<string, unknown>;
