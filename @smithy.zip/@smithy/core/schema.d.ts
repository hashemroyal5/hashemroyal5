/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
declare module "@smithy/core/schema" {
  export * from "@smithy/core/dist-types/submodules/schema/index.d";
}
