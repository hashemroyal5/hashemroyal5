# @smithy/smithy-client

[![NPM version](https://img.shields.io/npm/v/@smithy/smithy-client/latest.svg)](https://www.npmjs.com/package/@smithy/smithy-client)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/smithy-client.svg)](https://www.npmjs.com/package/@smithy/smithy-client)

> An internal package

## Usage

You probably shouldn't, at least directly.
