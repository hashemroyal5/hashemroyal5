export { collectBody } from "@smithy/core/protocols";
