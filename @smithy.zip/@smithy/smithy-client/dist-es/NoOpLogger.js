export class NoOpLogger {
    trace() { }
    debug() { }
    info() { }
    warn() { }
    error() { }
}
