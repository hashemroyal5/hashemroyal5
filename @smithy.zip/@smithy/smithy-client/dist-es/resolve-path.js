export { resolvedPath } from "@smithy/core/protocols";
