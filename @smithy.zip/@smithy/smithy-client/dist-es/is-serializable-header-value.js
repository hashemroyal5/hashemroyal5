export const isSerializableHeaderValue = (value) => {
    return value != null;
};
