export { extendedEncodeURIComponent } from "@smithy/core/protocols";
