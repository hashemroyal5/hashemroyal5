/**
 * @internal
 * Backwards compatibility re-export.
 */
export { resolvedPath } from "@smithy/core/protocols";
