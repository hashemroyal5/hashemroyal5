/**
 * @internal
 *
 * Recursively parses object and populates value is node from
 * "#text" key if it's available
 */
export declare const getValueFromTextNode: (obj: any) => any;
