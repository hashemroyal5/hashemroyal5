/**
 * @internal
 * Backwards compatibility re-export.
 */
export { collectBody } from "@smithy/core/protocols";
