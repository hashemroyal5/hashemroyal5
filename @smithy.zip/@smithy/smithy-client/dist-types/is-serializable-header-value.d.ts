/**
 * @internal
 * @returns whether the header value is serializable.
 */
export declare const isSerializableHeaderValue: (value: any) => boolean;
