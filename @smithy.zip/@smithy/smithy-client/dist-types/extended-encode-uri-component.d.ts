/**
 * @internal
 * Backwards compatibility re-export.
 */
export { extendedEncodeURIComponent } from "@smithy/core/protocols";
