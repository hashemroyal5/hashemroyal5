import { TestVectors } from "./vectorTypes.fixture";
export declare const vectors: TestVectors;
