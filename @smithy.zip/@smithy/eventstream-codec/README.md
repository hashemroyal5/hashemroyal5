# @smithy/eventstream-codec

[![NPM version](https://img.shields.io/npm/v/@smithy/eventstream-codec/latest.svg)](https://www.npmjs.com/package/@smithy/eventstream-codec)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/eventstream-codec.svg)](https://www.npmjs.com/package/@smithy/eventstream-codec)
