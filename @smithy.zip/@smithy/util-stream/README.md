# @smithy/util-stream

[![NPM version](https://img.shields.io/npm/v/@smithy/util-stream/latest.svg)](https://www.npmjs.com/package/@smithy/util-stream)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-stream.svg)](https://www.npmjs.com/package/@smithy/util-stream)

Package with utilities to operate on streams.
