export const SMITHY_CONTEXT_KEY = "__smithy_context";
