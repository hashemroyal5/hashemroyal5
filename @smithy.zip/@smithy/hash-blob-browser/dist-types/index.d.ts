import { StreamHasher } from "@smithy/types";
/**
 * @internal
 */
export declare const blobHasher: StreamHasher<Blob>;
