# @smithy/sha256-blob-browser

[![NPM version](https://img.shields.io/npm/v/@smithy/hash-blob-browser/latest.svg)](https://www.npmjs.com/package/@smithy/hash-blob-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/hash-blob-browser.svg)](https://www.npmjs.com/package/@smithy/hash-blob-browser)

> An internal package

## Usage

You probably shouldn't, at least directly.
