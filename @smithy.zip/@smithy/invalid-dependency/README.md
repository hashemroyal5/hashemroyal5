# @smithy/invalid-dependency

[![NPM version](https://img.shields.io/npm/v/@smithy/invalid-dependency/latest.svg)](https://www.npmjs.com/package/@smithy/invalid-dependency)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/invalid-dependency.svg)](https://www.npmjs.com/package/@smithy/invalid-dependency)

> An internal package

## Usage

You probably shouldn't, at least directly.
