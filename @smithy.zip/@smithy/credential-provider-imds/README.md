# @smithy/credential-provider-imds

[![NPM version](https://img.shields.io/npm/v/@smithy/credential-provider-imds/latest.svg)](https://www.npmjs.com/package/@smithy/credential-provider-imds)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/credential-provider-imds.svg)](https://www.npmjs.com/package/@smithy/credential-provider-imds)

> An internal package

## Usage

You probably shouldn't, at least directly. Please use [@smithy/credential-providers](https://www.npmjs.com/package/@smithy/credential-providers)
instead.
