# @smithy/util-config-provider

[![NPM version](https://img.shields.io/npm/v/@smithy/util-config-provider/latest.svg)](https://www.npmjs.com/package/@smithy/util-config-provider)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-config-provider.svg)](https://www.npmjs.com/package/@smithy/util-config-provider)
