export declare enum SelectorType {
    ENV = "env",
    CONFIG = "shared config entry"
}
