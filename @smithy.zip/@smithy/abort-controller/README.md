# @smithy/abort-controller

[![NPM version](https://img.shields.io/npm/v/@smithy/abort-controller/latest.svg)](https://www.npmjs.com/package/@smithy/abort-controller)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/abort-controller.svg)](https://www.npmjs.com/package/@smithy/abort-controller)
