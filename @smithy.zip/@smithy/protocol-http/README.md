# @smithy/protocol-http

[![NPM version](https://img.shields.io/npm/v/@smithy/protocol-http/latest.svg)](https://www.npmjs.com/package/@smithy/protocol-http)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/protocol-http.svg)](https://www.npmjs.com/package/@smithy/protocol-http)
