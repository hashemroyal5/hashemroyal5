# @smithy/is-array-buffer

[![NPM version](https://img.shields.io/npm/v/@smithy/is-array-buffer/latest.svg)](https://www.npmjs.com/package/@smithy/is-array-buffer)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/is-array-buffer.svg)](https://www.npmjs.com/package/@smithy/is-array-buffer)

> An internal package

## Usage

You probably shouldn't, at least directly.
