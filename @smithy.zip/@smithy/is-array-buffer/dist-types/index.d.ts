/**
 * @internal
 */
export declare const isArrayBuffer: (arg: any) => arg is ArrayBuffer;
