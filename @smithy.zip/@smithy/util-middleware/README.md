# @smithy/util-middleware

[![NPM version](https://img.shields.io/npm/v/@smithy/util-middleware/latest.svg)](https://www.npmjs.com/package/@smithy/util-middleware)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-middleware.svg)](https://www.npmjs.com/package/@smithy/util-middleware)

> An internal package

This package provides shared utilities for middleware.

## Usage

You probably shouldn't, at least directly.
