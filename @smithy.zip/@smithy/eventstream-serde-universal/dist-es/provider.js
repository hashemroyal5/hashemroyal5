import { EventStreamMarshaller } from "./EventStreamMarshaller";
export const eventStreamSerdeProvider = (options) => new EventStreamMarshaller(options);
