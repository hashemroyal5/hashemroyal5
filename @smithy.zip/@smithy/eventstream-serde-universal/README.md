# @smithy/eventstream-serde-universal

[![NPM version](https://img.shields.io/npm/v/@smithy/eventstream-serde-universal/latest.svg)](https://www.npmjs.com/package/@smithy/eventstream-serde-universal)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/eventstream-serde-universal.svg)](https://www.npmjs.com/package/@smithy/eventstream-serde-universal)

> An internal package

## Usage

You probably shouldn't, at least directly.
