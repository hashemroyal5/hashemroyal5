import { EventStreamSerdeProvider } from "@smithy/types";
/** NodeJS event stream utils provider */
export declare const eventStreamSerdeProvider: EventStreamSerdeProvider;
