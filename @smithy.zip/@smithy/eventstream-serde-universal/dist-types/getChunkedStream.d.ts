/**
 * @internal
 */
export declare function getChunkedStream(source: AsyncIterable<Uint8Array>): AsyncIterable<Uint8Array>;
