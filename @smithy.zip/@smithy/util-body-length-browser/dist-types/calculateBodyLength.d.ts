/**
 * @internal
 */
export declare const calculateBodyLength: (body: any) => number | undefined;
