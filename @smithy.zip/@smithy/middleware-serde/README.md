# @smithy/middleware-serde

[![NPM version](https://img.shields.io/npm/v/@smithy/middleware-serde/latest.svg)](https://www.npmjs.com/package/@smithy/middleware-serde)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/middleware-serde.svg)](https://www.npmjs.com/package/@smithy/middleware-serde)
