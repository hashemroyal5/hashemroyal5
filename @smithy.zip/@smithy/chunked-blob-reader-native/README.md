# @smithy/chunked-blob-reader-native

[![NPM version](https://img.shields.io/npm/v/@smithy/chunked-blob-reader-native/latest.svg)](https://www.npmjs.com/package/@smithy/chunked-blob-reader-native)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/chunked-blob-reader-native.svg)](https://www.npmjs.com/package/@smithy/chunked-blob-reader-native)

> An internal package

## Usage

You probably shouldn't, at least directly.
