# @smithy/middleware-endpoint

[![NPM version](https://img.shields.io/npm/v/@smithy/middleware-endpoint/latest.svg)](https://www.npmjs.com/package/@smithy/middleware-endpoint)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/middleware-endpoint.svg)](https://www.npmjs.com/package/@smithy/middleware-endpoint)

> An internal package

## Usage

You probably shouldn't, at least directly.
