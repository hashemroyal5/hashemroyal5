# @smithy/util-defaults-mode-browser

[![NPM version](https://img.shields.io/npm/v/@smithy/util-defaults-mode-browser/latest.svg)](https://www.npmjs.com/package/@smithy/util-defaults-mode-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-defaults-mode-browser.svg)](https://www.npmjs.com/package/@smithy/util-defaults-mode-browser)

> An internal package

## Usage

You probably shouldn't, at least directly.
