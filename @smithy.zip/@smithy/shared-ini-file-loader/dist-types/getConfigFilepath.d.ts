export declare const ENV_CONFIG_PATH = "AWS_CONFIG_FILE";
export declare const getConfigFilepath: () => string;
