import { ParsedIniData } from "@smithy/types";
export declare const parseIni: (iniData: string) => ParsedIniData;
