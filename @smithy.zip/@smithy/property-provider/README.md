# @smithy/property-provider

[![NPM version](https://img.shields.io/npm/v/@smithy/property-provider/latest.svg)](https://www.npmjs.com/package/@smithy/property-provider)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/property-provider.svg)](https://www.npmjs.com/package/@smithy/property-provider)

> An internal package

## Usage

You probably shouldn't, at least directly.
