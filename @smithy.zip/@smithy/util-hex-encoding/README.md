# @smithy/util-hex-encoding

[![NPM version](https://img.shields.io/npm/v/@smithy/util-hex-encoding/latest.svg)](https://www.npmjs.com/package/@smithy/util-hex-encoding)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-hex-encoding.svg)](https://www.npmjs.com/package/@smithy/util-hex-encoding)
