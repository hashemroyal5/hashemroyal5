# @smithy/node-config-provider

[![NPM version](https://img.shields.io/npm/v/@smithy/node-config-provider/latest.svg)](https://www.npmjs.com/package/@smithy/node-config-provider)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/node-config-provider.svg)](https://www.npmjs.com/package/@smithy/node-config-provider)

> An internal package

## Usage

You probably shouldn't, at least directly.
