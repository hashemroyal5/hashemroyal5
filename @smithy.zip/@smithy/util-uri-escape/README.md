# @smithy/util-uri-escape

[![NPM version](https://img.shields.io/npm/v/@smithy/util-uri-escape/latest.svg)](https://www.npmjs.com/package/@smithy/util-uri-escape)
[![NPM downloads](https://img.shields.io/npm/dm/@smithy/util-uri-escape.svg)](https://www.npmjs.com/package/@smithy/util-uri-escape)

> An internal package

## Usage

You probably shouldn't, at least directly.
