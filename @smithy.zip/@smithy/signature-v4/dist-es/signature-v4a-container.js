export const signatureV4aContainer = {
    SignatureV4a: null,
};
