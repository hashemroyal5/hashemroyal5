import { HttpRequest } from "@smithy/types";
/**
 * @internal
 */
export declare const getCanonicalQuery: ({ query }: HttpRequest) => string;
