import type { HttpRequest as IHttpRequest } from "@smithy/types";
/**
 * @internal
 */
export declare const prepareRequest: (request: IHttpRequest) => IHttpRequest;
