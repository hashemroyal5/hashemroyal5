export declare const iso8601: (time: number | string | Date) => string;
export declare const toDate: (time: number | string | Date) => Date;
