import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { 
  User, 
  LogOut, 
  Clock, 
  Calendar, 
  Package, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Plus, 
  Printer, 
  Users, 
  Settings, 
  BarChart3, 
  MessageSquare, 
  Bell,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Edit,
  Trash2,
  Store,
  UserPlus,
  Shield,
  Home,
  Send,
  Archive,
  TrendingUp,
  TrendingDown,
  Activity,
  Calendar as CalendarIcon,
  FileText,
  Mail,
  UserCheck,
  Building
} from "lucide-react";

// Types (same as before)
type UserRole = 'RFS' | 'OC' | 'RM';

interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  name: string;
  regionId?: string;
  restaurantId?: string;
  restaurants?: string[];
  createdAt: Date;
}

interface Region {
  id: string;
  name: string;
  ocId: string;
  restaurantCount: number;
  restaurants: Restaurant[];
}

interface Restaurant {
  id: string;
  name: string;
  regionId: string;
  managerId?: string;
  address: string;
}

type ProductCategory = 'meat' | 'chicken' | 'bakery' | 'vegetables' | 'beverages' | 'condiments' | 'frozen' | 'dairy' | 'mccafe';

interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  color: string;
  defaultShelfLifeHours: number;
  isDailyProduct: boolean;
  requiresThawing: boolean;
  thawTimeHours?: number;
  notes?: string;
  isActive: boolean;
  labelSize: 'small' | 'medium' | 'large';
}

type InventoryStatus = 'fresh' | 'warning' | 'expired';

interface InventoryItem {
  id: string;
  productId: string;
  restaurantId: string;
  quantity: number;
  receivedDate: Date;
  expiryDate: Date;
  status: InventoryStatus;
  batchNumber?: string;
  isDaily: boolean;
  autoRenew?: boolean;
  renewalHours?: number;
}

interface PrintLabel {
  id: string;
  productName: string;
  quantity: number;
  thawDate?: Date;
  useByDate: Date;
  wasteDate: Date;
  restaurantName: string;
  printedAt: Date;
  labelSize: 'small' | 'medium' | 'large';
}

interface Message {
  id: string;
  fromUserId: string;
  toUserId?: string;
  toRole?: UserRole;
  subject: string;
  content: string;
  isRead: boolean;
  createdAt: Date;
  isSystemMessage: boolean;
}

interface Notification {
  id: string;
  userId: string;
  type: 'expiration' | 'system' | 'message';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  expiresAt?: Date;
}

type Season = 'summer' | 'winter' | 'spring' | 'autumn';

interface SeasonalAdjustment {
  id: string;
  season: Season;
  category: ProductCategory | 'all';
  adjustmentType: 'percentage' | 'hours';
  adjustmentValue: number; // Percentage (0.8 = 80%, 1.2 = 120%) or hours to add/subtract
  isActive: boolean;
  notes?: string;
}

interface SeasonalSettings {
  currentSeason: Season;
  autoDetectSeason: boolean;
  adjustments: SeasonalAdjustment[];
  temperatureThresholds: {
    summer: number; // °F
    winter: number; // °F
  };
}

interface Report {
  id: string;
  type: 'weekly' | 'monthly' | 'yearly';
  period: string;
  data: {
    totalItems: number;
    freshItems: number;
    expiredItems: number;
    wasteReduction: number;
    costSavings: number;
    labelsPlinted: number;
  };
  generatedAt: Date;
}

// Initial Data with comprehensive McDonald's product catalog
const INITIAL_PRODUCTS: Product[] = [
  // Meat & Chicken Products
  { id: '1', name: 'BEEF PATTIES 4:1', category: 'meat', color: 'bg-red-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 24, isActive: true, labelSize: 'medium', notes: 'Thaw 24hrs before use - Use within 48hrs after thawing' },
  { id: '2', name: 'BEEF PATTIES 10:1', category: 'meat', color: 'bg-red-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 24, isActive: true, labelSize: 'medium', notes: 'Regular burger patties - Thaw 24hrs before use' },
  { id: '3', name: 'ANGUS BEEF PATTIES', category: 'meat', color: 'bg-red-700', defaultShelfLifeHours: 36, isDailyProduct: false, requiresThawing: true, thawTimeHours: 24, isActive: true, labelSize: 'medium', notes: 'Premium Angus beef - Handle with care' },
  { id: '4', name: 'CHICKEN NUGGETS', category: 'chicken', color: 'bg-orange-500', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium', notes: 'Thaw 12hrs - Fry at 350°F for 3-4 minutes' },
  { id: '5', name: 'FAJITA CHICKEN', category: 'chicken', color: 'bg-orange-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 18, isActive: true, labelSize: 'medium', notes: 'Pre-seasoned strips - Thaw 18hrs before use' },
  { id: '6', name: 'GRILLED CHICKEN BREAST', category: 'chicken', color: 'bg-yellow-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium', notes: 'Premium chicken - Grill to 165°F internal temp' },
  { id: '7', name: 'CRISPY CHICKEN BREAST', category: 'chicken', color: 'bg-orange-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium', notes: 'Breaded chicken - Fry at 350°F' },
  { id: '8', name: 'SPICY CHICKEN BREAST', category: 'chicken', color: 'bg-red-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'medium', notes: 'Spicy breaded chicken - Handle with gloves' },
  { id: '9', name: 'FISH FILLETS', category: 'meat', color: 'bg-blue-600', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 8, isActive: true, labelSize: 'medium', notes: 'Pollock fillets - Thaw 8hrs before use' },
  { id: '10', name: 'SAUSAGE PATTIES', category: 'meat', color: 'bg-red-300', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: true, thawTimeHours: 12, isActive: true, labelSize: 'small', notes: 'Breakfast sausage - Cook to 160°F' },
  { id: '11', name: 'CANADIAN BACON', category: 'meat', color: 'bg-pink-600', defaultShelfLifeHours: 120, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Pre-cooked ham - Keep refrigerated' },
  
  // Bakery Products
  { id: '12', name: 'BIG MAC BUNS', category: 'bakery', color: 'bg-amber-500', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large', notes: 'Sesame seed buns - Store in dry area' },
  { id: '13', name: 'QUARTER POUNDER BUNS', category: 'bakery', color: 'bg-amber-600', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large', notes: 'Large sesame buns - Keep covered' },
  { id: '14', name: 'REGULAR HAMBURGER BUNS', category: 'bakery', color: 'bg-yellow-500', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Standard burger buns - Use FIFO rotation' },
  { id: '15', name: 'ENGLISH MUFFINS', category: 'bakery', color: 'bg-yellow-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Breakfast muffins - Toast before serving' },
  { id: '16', name: 'TORTILLA WRAPS', category: 'bakery', color: 'bg-yellow-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Flour tortillas - Keep sealed' },
  { id: '17', name: 'BAGELS', category: 'bakery', color: 'bg-amber-400', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Plain bagels - Toast before serving' },
  { id: '18', name: 'BISCUITS', category: 'bakery', color: 'bg-yellow-300', defaultShelfLifeHours: 8, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Fresh baked daily - 8hr shelf life' },
  { id: '19', name: 'APPLE PIES PASTRY', category: 'bakery', color: 'bg-red-200', defaultShelfLifeHours: 96, isDailyProduct: false, requiresThawing: true, thawTimeHours: 4, isActive: true, labelSize: 'small', notes: 'Frozen pastry - Thaw 4hrs before baking' },
  
  // Vegetables & Fresh Products
  { id: '20', name: 'ICEBERG LETTUCE', category: 'vegetables', color: 'bg-green-500', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large', notes: 'Keep refrigerated 35-38°F - Check for browning' },
  { id: '21', name: 'LEAF LETTUCE', category: 'vegetables', color: 'bg-green-400', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Delicate greens - Handle gently' },
  { id: '22', name: 'TOMATOES', category: 'vegetables', color: 'bg-red-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Room temp storage until cut - Refrigerate after slicing' },
  { id: '23', name: 'WHITE ONIONS', category: 'vegetables', color: 'bg-purple-200', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Fresh onions - Store in cool dry place' },
  { id: '24', name: 'RECONSTITUTED ONIONS', category: 'vegetables', color: 'bg-purple-400', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Rehydrated onions - Use within 24hrs' },
  { id: '25', name: 'DEHYDRATED ONIONS', category: 'vegetables', color: 'bg-purple-500', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Dry storage - Long shelf life' },
  { id: '26', name: 'CAESAR SALAD MIX', category: 'vegetables', color: 'bg-green-400', defaultShelfLifeHours: 6, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Fresh prep daily - 6hr max shelf life' },
  { id: '27', name: 'SIDE SALAD MIX', category: 'vegetables', color: 'bg-green-300', defaultShelfLifeHours: 8, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Mixed greens - 8hr shelf life' },
  { id: '28', name: 'SHREDDED LETTUCE', category: 'vegetables', color: 'bg-green-200', defaultShelfLifeHours: 4, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Fresh shredded - 4hr max' },
  
  // Frozen Products
  { id: '29', name: 'FRENCH FRIES', category: 'frozen', color: 'bg-yellow-300', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large', notes: 'Keep frozen until cooking - Fry at 350°F' },
  { id: '30', name: 'HASH BROWNS', category: 'frozen', color: 'bg-yellow-700', defaultShelfLifeHours: 24, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Breakfast item - Keep frozen' },
  { id: '31', name: 'APPLE SLICES', category: 'frozen', color: 'bg-red-100', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: true, thawTimeHours: 2, isActive: true, labelSize: 'small', notes: 'Thaw 2hrs before serving - Keep chilled' },
  { id: '32', name: 'VANILLA ICE CREAM', category: 'frozen', color: 'bg-blue-100', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Keep frozen at -5°F to 0°F' },
  { id: '33', name: 'STRAWBERRY ICE CREAM', category: 'frozen', color: 'bg-pink-200', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Keep frozen - Check for crystals' },
  { id: '34', name: 'CHOCOLATE ICE CREAM', category: 'frozen', color: 'bg-amber-800', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Keep frozen - Rotate stock' },
  
  // Beverages
  { id: '35', name: 'APPLE JUICE', category: 'beverages', color: 'bg-red-300', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Happy Meal drink - Refrigerate after opening' },
  { id: '36', name: 'ORANGE JUICE', category: 'beverages', color: 'bg-orange-400', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Breakfast beverage - Keep chilled' },
  { id: '37', name: 'CHOCOLATE MILK', category: 'beverages', color: 'bg-amber-700', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Kids drink option - Keep refrigerated' },
  { id: '38', name: 'COCA-COLA SYRUP', category: 'beverages', color: 'bg-red-700', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'BIB syrup - Check expiry date' },
  { id: '39', name: 'SPRITE SYRUP', category: 'beverages', color: 'bg-green-600', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'BIB syrup - Lemon-lime flavor' },
  { id: '40', name: 'FANTA ORANGE SYRUP', category: 'beverages', color: 'bg-orange-600', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'BIB syrup - Orange flavor' },
  { id: '41', name: 'DIET COKE SYRUP', category: 'beverages', color: 'bg-gray-700', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Sugar-free syrup - Check calibration' },
  { id: '42', name: 'HI-C ORANGE SYRUP', category: 'beverages', color: 'bg-orange-500', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Kids drink syrup - Vitamin C fortified' },
  
  // Condiments & Sauces
  { id: '43', name: 'BIG MAC SAUCE', category: 'condiments', color: 'bg-orange-300', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Secret sauce - Keep refrigerated' },
  { id: '44', name: 'BIG TASTY SAUCE', category: 'condiments', color: 'bg-orange-400', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Premium burger sauce' },
  { id: '45', name: 'THOUSAND ISLAND', category: 'condiments', color: 'bg-pink-400', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Salad dressing - Check consistency' },
  { id: '46', name: 'RANCH DRESSING', category: 'condiments', color: 'bg-white', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Creamy dressing - Shake before use' },
  { id: '47', name: 'CAESAR DRESSING', category: 'condiments', color: 'bg-yellow-200', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Parmesan dressing' },
  { id: '48', name: 'KETCHUP PACKETS', category: 'condiments', color: 'bg-red-500', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Individual packets - Long shelf life' },
  { id: '49', name: 'MUSTARD PACKETS', category: 'condiments', color: 'bg-yellow-400', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Yellow mustard packets' },
  { id: '50', name: 'MAYONNAISE', category: 'condiments', color: 'bg-yellow-100', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Keep refrigerated - Check oil separation' },
  { id: '51', name: 'PICKLES', category: 'condiments', color: 'bg-green-700', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Dill pickle slices - Keep in brine' },
  { id: '52', name: 'JALAPENOS', category: 'condiments', color: 'bg-green-600', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Spicy peppers - Use gloves when handling' },
  { id: '53', name: 'VEGETABLE OIL', category: 'condiments', color: 'bg-yellow-200', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'large', notes: 'Frying oil - Filter daily, change when dark' },
  { id: '54', name: 'BARBECUE SAUCE', category: 'condiments', color: 'bg-red-600', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Tangy BBQ sauce - Check viscosity' },
  { id: '55', name: 'HOT MUSTARD SAUCE', category: 'condiments', color: 'bg-yellow-600', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Spicy mustard - Limited availability' },
  { id: '56', name: 'SWEET & SOUR SAUCE', category: 'condiments', color: 'bg-orange-200', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Nugget sauce - Check for separation' },
  
  // Dairy Products
  { id: '57', name: 'MILK 2%', category: 'dairy', color: 'bg-blue-200', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'For McCafe and cereal - Check expiry daily' },
  { id: '58', name: 'SKIM MILK', category: 'dairy', color: 'bg-blue-100', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Fat-free milk option' },
  { id: '59', name: 'HEAVY CREAM', category: 'dairy', color: 'bg-yellow-100', defaultShelfLifeHours: 120, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'For McCafe drinks - Keep cold' },
  { id: '60', name: 'AMERICAN CHEESE SLICES', category: 'dairy', color: 'bg-yellow-600', defaultShelfLifeHours: 120, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Processed cheese - Keep wrapped' },
  { id: '61', name: 'SWISS CHEESE SLICES', category: 'dairy', color: 'bg-yellow-300', defaultShelfLifeHours: 120, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Natural Swiss cheese' },
  { id: '62', name: 'SHREDDED CHEESE', category: 'dairy', color: 'bg-yellow-500', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Mixed cheese blend - Keep sealed' },
  { id: '63', name: 'BUTTER', category: 'dairy', color: 'bg-yellow-200', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Salted butter - Keep refrigerated' },
  { id: '64', name: 'EGGS (SHELL)', category: 'dairy', color: 'bg-yellow-50', defaultShelfLifeHours: 504, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Fresh eggs - Check for cracks' },
  { id: '65', name: 'FOLDED EGGS', category: 'dairy', color: 'bg-yellow-400', defaultShelfLifeHours: 4, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Pre-cooked eggs - 4hr holding time' },
  { id: '66', name: 'SCRAMBLED EGGS', category: 'dairy', color: 'bg-yellow-300', defaultShelfLifeHours: 2, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Fresh scrambled - 2hr max hold' },
  
  // McCafe Products
  { id: '67', name: 'COFFEE BEANS (PREMIUM)', category: 'mccafe', color: 'bg-amber-700', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Premium Arabica - Grind fresh daily' },
  { id: '68', name: 'COFFEE BEANS (DECAF)', category: 'mccafe', color: 'bg-amber-600', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Decaffeinated beans' },
  { id: '69', name: 'ESPRESSO BEANS', category: 'mccafe', color: 'bg-amber-800', defaultShelfLifeHours: 336, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Dark roast for espresso drinks' },
  { id: '70', name: 'CARAMEL SAUCE', category: 'mccafe', color: 'bg-amber-600', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Sweet caramel - Heat before use' },
  { id: '71', name: 'CHOCOLATE SAUCE', category: 'mccafe', color: 'bg-amber-900', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Chocolate syrup - Stir before use' },
  { id: '72', name: 'VANILLA SYRUP', category: 'mccafe', color: 'bg-yellow-100', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Flavoring syrup - Sugar-based' },
  { id: '73', name: 'HAZELNUT SYRUP', category: 'mccafe', color: 'bg-amber-500', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Nut flavoring - Check for allergies' },
  { id: '74', name: 'WHIPPED CREAM', category: 'mccafe', color: 'bg-blue-100', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Keep refrigerated - Shake before use' },
  { id: '75', name: 'FRAPPUCCINO BASE', category: 'mccafe', color: 'bg-blue-300', defaultShelfLifeHours: 168, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Blended drink base - Keep chilled' },
  { id: '76', name: 'SMOOTHIE MIX', category: 'mccafe', color: 'bg-pink-300', defaultShelfLifeHours: 72, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Fruit smoothie base - Refrigerate' },
  { id: '77', name: 'HOT CHOCOLATE MIX', category: 'mccafe', color: 'bg-amber-400', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Powder mix - Keep dry' },
  { id: '78', name: 'TEA BAGS (ASSORTED)', category: 'mccafe', color: 'bg-green-300', defaultShelfLifeHours: 2160, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Various tea flavors - Keep dry' },

  // Additional Specialty Items
  { id: '79', name: 'APPLE PIE FILLING', category: 'frozen', color: 'bg-red-200', defaultShelfLifeHours: 240, isDailyProduct: false, requiresThawing: true, thawTimeHours: 4, isActive: true, labelSize: 'medium', notes: 'Thaw 4hrs before baking - Keep frozen until use' },
  { id: '80', name: 'COOKIES (CHOCOLATE CHIP)', category: 'bakery', color: 'bg-amber-300', defaultShelfLifeHours: 48, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Baked cookies - Store in airtight container' },
  { id: '81', name: 'MUFFIN MIX', category: 'bakery', color: 'bg-yellow-300', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Dry mix - Add water and bake' },
  { id: '82', name: 'PANCAKE BATTER', category: 'bakery', color: 'bg-yellow-200', defaultShelfLifeHours: 24, isDailyProduct: true, requiresThawing: false, isActive: true, labelSize: 'medium', notes: 'Fresh batter - Use within 24hrs' },
  { id: '83', name: 'HOTCAKE SYRUP', category: 'condiments', color: 'bg-amber-300', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Maple flavored syrup - Individual packets' },
  { id: '84', name: 'GRAPE JAM', category: 'condiments', color: 'bg-purple-300', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Individual jam packets' },
  { id: '85', name: 'STRAWBERRY JAM', category: 'condiments', color: 'bg-red-300', defaultShelfLifeHours: 720, isDailyProduct: false, requiresThawing: false, isActive: true, labelSize: 'small', notes: 'Individual jam packets' }
];

// Initial seasonal settings
const INITIAL_SEASONAL_SETTINGS: SeasonalSettings = {
  currentSeason: 'summer', // Default to summer for food safety
  autoDetectSeason: true,
  temperatureThresholds: {
    summer: 75, // Above 75°F is considered summer
    winter: 45  // Below 45°F is considered winter
  },
  adjustments: [
    // Summer adjustments (reduce shelf life for safety)
    {
      id: 'adj-1',
      season: 'summer',
      category: 'dairy',
      adjustmentType: 'percentage',
      adjustmentValue: 0.75, // 75% of normal shelf life
      isActive: true,
      notes: 'Dairy products spoil faster in high temperatures'
    },
    {
      id: 'adj-2',
      season: 'summer',
      category: 'vegetables',
      adjustmentType: 'percentage',
      adjustmentValue: 0.8, // 80% of normal shelf life
      isActive: true,
      notes: 'Fresh vegetables wilt faster in summer heat'
    },
    {
      id: 'adj-3',
      season: 'summer',
      category: 'meat',
      adjustmentType: 'percentage',
      adjustmentValue: 0.85, // 85% of normal shelf life
      isActive: true,
      notes: 'Critical for food safety in high temperatures'
    },
    {
      id: 'adj-4',
      season: 'summer',
      category: 'chicken',
      adjustmentType: 'percentage',
      adjustmentValue: 0.85, // 85% of normal shelf life
      isActive: true,
      notes: 'Poultry requires extra caution in summer'
    },
    // Winter adjustments (can extend some shelf life)
    {
      id: 'adj-5',
      season: 'winter',
      category: 'bakery',
      adjustmentType: 'percentage',
      adjustmentValue: 1.1, // 110% of normal shelf life
      isActive: true,
      notes: 'Dry goods last longer in cold weather'
    },
    {
      id: 'adj-6',
      season: 'winter',
      category: 'condiments',
      adjustmentType: 'percentage',
      adjustmentValue: 1.05, // 105% of normal shelf life
      isActive: true,
      notes: 'Shelf-stable items benefit from cool temperatures'
    }
  ]
};

const INITIAL_RESTAURANTS: Restaurant[] = [
  { id: 'rest-1', name: 'McDonald\'s Downtown', regionId: 'region-1', address: '123 Main St, Downtown', managerId: undefined },
  { id: 'rest-2', name: 'McDonald\'s Mall Plaza', regionId: 'region-1', address: '456 Mall Rd, Plaza District', managerId: undefined },
  { id: 'rest-3', name: 'McDonald\'s Airport', regionId: 'region-1', address: '789 Airport Blvd, Terminal 1', managerId: undefined },
  { id: 'rest-4', name: 'McDonald\'s Uptown', regionId: 'region-2', address: '321 Uptown Ave, Business District', managerId: undefined },
  { id: 'rest-5', name: 'McDonald\'s Suburban', regionId: 'region-2', address: '654 Suburban Way, Residential Area', managerId: undefined }
];

const INITIAL_REGIONS: Region[] = [
  { id: 'region-1', name: 'Central Region', ocId: 'oc-1', restaurantCount: 3, restaurants: INITIAL_RESTAURANTS.slice(0, 3) },
  { id: 'region-2', name: 'North Region', ocId: 'oc-2', restaurantCount: 2, restaurants: INITIAL_RESTAURANTS.slice(3, 5) }
];

const INITIAL_USERS: User[] = [
  {
    id: 'rfs-1',
    username: 'RFS',
    password: 'RFS@PC123',
    role: 'RFS',
    name: 'System Administrator',
    createdAt: new Date()
  },
  {
    id: 'oc-1',
    username: 'OC001',
    password: 'OC123',
    role: 'OC',
    name: 'John Smith',
    regionId: 'region-1',
    restaurants: ['rest-1', 'rest-2', 'rest-3'],
    createdAt: new Date()
  },
  {
    id: 'oc-2',
    username: 'OC002',
    password: 'OC456',
    role: 'OC',
    name: 'Sarah Johnson',
    regionId: 'region-2',
    restaurants: ['rest-4', 'rest-5'],
    createdAt: new Date()
  },
  {
    id: 'rm-1',
    username: 'RM001',
    password: 'RM123',
    role: 'RM',
    name: 'Mike Wilson',
    regionId: 'region-1',
    restaurantId: 'rest-1',
    createdAt: new Date()
  },
  {
    id: 'rm-2',
    username: 'RM002',
    password: 'RM456',
    role: 'RM',
    name: 'Lisa Brown',
    regionId: 'region-1',
    restaurantId: 'rest-2',
    createdAt: new Date()
  }
];

// Sample messages and reports
const INITIAL_MESSAGES: Message[] = [
  {
    id: 'msg-1',
    fromUserId: 'oc-1',
    toUserId: 'rm-1',
    subject: 'Inventory Review',
    content: 'Please ensure all expired items are properly disposed of according to food safety protocols.',
    isRead: false,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    isSystemMessage: false
  },
  {
    id: 'msg-2',
    fromUserId: 'rfs-1',
    toRole: 'OC',
    subject: 'System Update',
    content: 'New features have been added to the thermal printing system. Please review the updated procedures.',
    isRead: false,
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    isSystemMessage: true
  }
];

// Sample inventory items for testing
const INITIAL_INVENTORY: InventoryItem[] = [
  // Fresh items (expires in several hours)
  {
    id: 'inv-1',
    productId: '1', // BEEF PATTIES 4:1
    restaurantId: 'rest-1',
    quantity: 20,
    receivedDate: new Date(Date.now() - 2 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 46 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'BP240215001',
    isDaily: false
  },
  {
    id: 'inv-2',
    productId: '4', // CHICKEN NUGGETS
    restaurantId: 'rest-1',
    quantity: 15,
    receivedDate: new Date(Date.now() - 1 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 71 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'CN240215002',
    isDaily: false
  },
  {
    id: 'inv-3',
    productId: '12', // BIG MAC BUNS
    restaurantId: 'rest-1',
    quantity: 48,
    receivedDate: new Date(Date.now() - 30 * 60 * 1000),
    expiryDate: new Date(Date.now() + 23.5 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'BMB240215003',
    isDaily: false
  },
  
  // Warning items (expires within 30 minutes)
  {
    id: 'inv-4',
    productId: '26', // CAESAR SALAD MIX
    restaurantId: 'rest-1',
    quantity: 8,
    receivedDate: new Date(Date.now() - 5.5 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 25 * 60 * 1000),
    status: 'warning',
    isDaily: true,
    autoRenew: true,
    renewalHours: 6
  },
  {
    id: 'inv-5',
    productId: '65', // FOLDED EGGS
    restaurantId: 'rest-1',
    quantity: 12,
    receivedDate: new Date(Date.now() - 3.5 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 15 * 60 * 1000),
    status: 'warning',
    batchNumber: 'FE240215004',
    isDaily: true
  },
  
  // Expired items
  {
    id: 'inv-6',
    productId: '66', // SCRAMBLED EGGS
    restaurantId: 'rest-1',
    quantity: 6,
    receivedDate: new Date(Date.now() - 3 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() - 30 * 60 * 1000),
    status: 'expired',
    isDaily: true
  },
  {
    id: 'inv-7',
    productId: '28', // SHREDDED LETTUCE
    restaurantId: 'rest-1',
    quantity: 4,
    receivedDate: new Date(Date.now() - 5 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() - 1 * 60 * 60 * 1000),
    status: 'expired',
    isDaily: true
  },
  
  // Items for other restaurants
  {
    id: 'inv-8',
    productId: '29', // FRENCH FRIES
    restaurantId: 'rest-2',
    quantity: 30,
    receivedDate: new Date(Date.now() - 1 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 23 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'FF240215005',
    isDaily: false
  },
  {
    id: 'inv-9',
    productId: '67', // COFFEE BEANS (PREMIUM)
    restaurantId: 'rest-2',
    quantity: 5,
    receivedDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 312 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'CB240214001',
    isDaily: false
  },
  {
    id: 'inv-10',
    productId: '74', // WHIPPED CREAM
    restaurantId: 'rest-2',
    quantity: 3,
    receivedDate: new Date(Date.now() - 50 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 22 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'WC240213001',
    isDaily: false
  },
  
  // McCafe items with different statuses
  {
    id: 'inv-11',
    productId: '70', // CARAMEL SAUCE
    restaurantId: 'rest-1',
    quantity: 2,
    receivedDate: new Date(Date.now() - 120 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 48 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'CS240210001',
    isDaily: false
  },
  
  // Beverages
  {
    id: 'inv-12',
    productId: '38', // COCA-COLA SYRUP
    restaurantId: 'rest-1',
    quantity: 1,
    receivedDate: new Date(Date.now() - 48 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 288 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'CCS240213001',
    isDaily: false
  },
  
  // Dairy products
  {
    id: 'inv-13',
    productId: '57', // MILK 2%
    restaurantId: 'rest-1',
    quantity: 4,
    receivedDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 144 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'M2240214001',
    isDaily: false
  },
  
  // Condiments
  {
    id: 'inv-14',
    productId: '44', // BIG TASTY SAUCE
    restaurantId: 'rest-1',
    quantity: 6,
    receivedDate: new Date(Date.now() - 12 * 60 * 60 * 1000),
    expiryDate: new Date(Date.now() + 60 * 60 * 60 * 1000),
    status: 'fresh',
    batchNumber: 'BTS240214002',
    isDaily: false
  }
];

// Main App Component (keeping all the existing functionality and adding new complete tabs)
export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  
  // Application State
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [regions, setRegions] = useState<Region[]>(INITIAL_REGIONS);
  const [restaurants, setRestaurants] = useState<Restaurant[]>(INITIAL_RESTAURANTS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [seasonalSettings, setSeasonalSettings] = useState<SeasonalSettings>(INITIAL_SEASONAL_SETTINGS);
  const [printQueue, setPrintQueue] = useState<PrintLabel[]>([
    {
      id: 'label-1',
      productName: 'CAESAR SALAD MIX',
      quantity: 8,
      useByDate: new Date(Date.now() + 25 * 60 * 1000),
      wasteDate: new Date(Date.now() + 25 * 60 * 1000 + 2 * 60 * 60 * 1000),
      restaurantName: 'McDonald\'s Downtown',
      printedAt: new Date(Date.now() - 10 * 60 * 1000),
      labelSize: 'small'
    },
    {
      id: 'label-2',
      productName: 'BEEF PATTIES 4:1',
      quantity: 20,
      thawDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      useByDate: new Date(Date.now() + 46 * 60 * 60 * 1000),
      wasteDate: new Date(Date.now() + 48 * 60 * 60 * 1000),
      restaurantName: 'McDonald\'s Downtown',
      printedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      labelSize: 'medium'
    },
    {
      id: 'label-3',
      productName: 'BIG MAC BUNS',
      quantity: 48,
      useByDate: new Date(Date.now() + 23.5 * 60 * 60 * 1000),
      wasteDate: new Date(Date.now() + 25.5 * 60 * 60 * 1000),
      restaurantName: 'McDonald\'s Downtown',
      printedAt: new Date(Date.now() - 30 * 60 * 1000),
      labelSize: 'large'
    }
  ]);
  
  // UI State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [showCreateUserDialog, setShowCreateUserDialog] = useState(false);
  const [showAddProductDialog, setShowAddProductDialog] = useState(false);
  const [showAddInventoryDialog, setShowAddInventoryDialog] = useState(false);
  const [showPrintDialog, setShowPrintDialog] = useState(false);
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [showEditProductDialog, setShowEditProductDialog] = useState(false);
  const [showSeasonalSettingsDialog, setShowSeasonalSettingsDialog] = useState(false);
  const [showAddSeasonalAdjustmentDialog, setShowAddSeasonalAdjustmentDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSeasonalAdjustment, setSelectedSeasonalAdjustment] = useState<SeasonalAdjustment | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<ProductCategory | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<InventoryStatus | 'all'>('all');

  // Form states
  const [newUserForm, setNewUserForm] = useState({
    username: '',
    password: '',
    name: '',
    role: 'RM' as UserRole,
    regionId: '',
    restaurantId: ''
  });

  const [newProductForm, setNewProductForm] = useState({
    name: '',
    category: 'meat' as ProductCategory,
    color: 'bg-red-500',
    defaultShelfLifeHours: 24,
    isDailyProduct: false,
    requiresThawing: false,
    thawTimeHours: 0,
    notes: '',
    labelSize: 'medium' as 'small' | 'medium' | 'large'
  });

  const [messageForm, setMessageForm] = useState({
    toUserId: '',
    toRole: undefined as UserRole | undefined,
    subject: '',
    content: ''
  });
  
  const [seasonalAdjustmentForm, setSeasonalAdjustmentForm] = useState({
    season: 'summer' as Season,
    category: 'all' as ProductCategory | 'all',
    adjustmentType: 'percentage' as 'percentage' | 'hours',
    adjustmentValue: 1.0,
    notes: ''
  });

  // Seasonal adjustment utility functions
  const getAdjustedShelfLife = (product: Product): number => {
    let adjustedHours = product.defaultShelfLifeHours;
    
    // Apply seasonal adjustments
    const applicableAdjustments = seasonalSettings.adjustments.filter(adj => 
      adj.isActive && 
      adj.season === seasonalSettings.currentSeason && 
      (adj.category === product.category || adj.category === 'all')
    );
    
    applicableAdjustments.forEach(adj => {
      if (adj.adjustmentType === 'percentage') {
        adjustedHours = adjustedHours * adj.adjustmentValue;
      } else if (adj.adjustmentType === 'hours') {
        adjustedHours = adjustedHours + adj.adjustmentValue;
      }
    });
    
    // Ensure minimum 1 hour and maximum reasonable limits
    return Math.max(1, Math.round(adjustedHours));
  };
  
  const detectSeason = (): Season => {
    if (!seasonalSettings.autoDetectSeason) {
      return seasonalSettings.currentSeason;
    }
    
    const month = new Date().getMonth() + 1; // 1-12
    
    if (month >= 6 && month <= 8) {
      return 'summer';
    } else if (month >= 12 || month <= 2) {
      return 'winter';
    } else if (month >= 3 && month <= 5) {
      return 'spring';
    } else {
      return 'autumn';
    }
  };
  
  const updateSeasonalSettings = (updates: Partial<SeasonalSettings>) => {
    setSeasonalSettings(prev => ({ ...prev, ...updates }));
  };
  
  const addSeasonalAdjustment = (adjustment: Omit<SeasonalAdjustment, 'id'>) => {
    const newAdjustment: SeasonalAdjustment = {
      ...adjustment,
      id: `adj-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };
    
    setSeasonalSettings(prev => ({
      ...prev,
      adjustments: [...prev.adjustments, newAdjustment]
    }));
  };
  
  const updateSeasonalAdjustment = (id: string, updates: Partial<SeasonalAdjustment>) => {
    setSeasonalSettings(prev => ({
      ...prev,
      adjustments: prev.adjustments.map(adj => 
        adj.id === id ? { ...adj, ...updates } : adj
      )
    }));
  };
  
  const deleteSeasonalAdjustment = (id: string) => {
    setSeasonalSettings(prev => ({
      ...prev,
      adjustments: prev.adjustments.filter(adj => adj.id !== id)
    }));
  };

  // Auto-detect season on component mount and update seasonally
  useEffect(() => {
    if (seasonalSettings.autoDetectSeason) {
      const currentSeason = detectSeason();
      if (currentSeason !== seasonalSettings.currentSeason) {
        setSeasonalSettings(prev => ({ ...prev, currentSeason }));
      }
    }
  }, [seasonalSettings.autoDetectSeason]);

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Check for expiring items and create notifications
  useEffect(() => {
    const checkExpirations = () => {
      const now = new Date();
      const thirtyMinutesFromNow = new Date(now.getTime() + 30 * 60 * 1000);
      
      inventory.forEach(item => {
        if (item.expiryDate <= thirtyMinutesFromNow && item.expiryDate > now) {
          const product = products.find(p => p.id === item.productId);
          if (product) {
            const notificationId = `exp-${item.id}-${item.expiryDate.getTime()}`;
            const existingNotification = notifications.find(n => n.id === notificationId);
            
            if (!existingNotification) {
              const newNotification: Notification = {
                id: notificationId,
                userId: currentUser?.id || '',
                type: 'expiration',
                title: 'Expiration Warning',
                message: `${product.name} expires in 30 minutes!`,
                isRead: false,
                createdAt: now,
                expiresAt: item.expiryDate
              };
              setNotifications(prev => [...prev, newNotification]);
              
              // Auto-print label for expiring items
              if (currentUser?.role === 'RM') {
                printLabel(item.id);
              }
            }
          }
        }
        
        // Update inventory status
        let newStatus: InventoryStatus;
        if (item.expiryDate <= now) {
          newStatus = 'expired';
        } else if (item.expiryDate <= thirtyMinutesFromNow) {
          newStatus = 'warning';
        } else {
          newStatus = 'fresh';
        }
        
        if (item.status !== newStatus) {
          setInventory(prev => prev.map(inv => 
            inv.id === item.id ? { ...inv, status: newStatus } : inv
          ));
        }
      });
    };
    
    const interval = setInterval(checkExpirations, 60000); // Check every minute
    checkExpirations(); // Check immediately
    
    return () => clearInterval(interval);
  }, [inventory, products, notifications, currentUser]);

  // Authentication Functions
  const handleLogin = () => {
    const user = users.find(u => 
      u.username === loginForm.username && u.password === loginForm.password
    );
    
    if (user) {
      setCurrentUser(user);
      setLoginError('');
      setLoginForm({ username: '', password: '' });
    } else {
      setLoginError('Invalid username or password');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab('dashboard');
  };

  // User Management Functions
  const createUser = () => {
    if (!newUserForm.username || !newUserForm.password || !newUserForm.name) return;
    
    const newUser: User = {
      id: `user-${Date.now()}`,
      username: newUserForm.username,
      password: newUserForm.password,
      role: newUserForm.role,
      name: newUserForm.name,
      regionId: newUserForm.regionId || undefined,
      restaurantId: newUserForm.restaurantId || undefined,
      restaurants: newUserForm.role === 'OC' ? regions.find(r => r.id === newUserForm.regionId)?.restaurants.map(r => r.id) : undefined,
      createdAt: new Date()
    };
    
    setUsers(prev => [...prev, newUser]);
    setNewUserForm({
      username: '',
      password: '',
      name: '',
      role: 'RM',
      regionId: '',
      restaurantId: ''
    });
    setShowCreateUserDialog(false);
  };

  // Product Management Functions
  const addProduct = () => {
    if (!newProductForm.name) return;
    
    const newProduct: Product = {
      id: `prod-${Date.now()}`,
      name: newProductForm.name.toUpperCase(),
      category: newProductForm.category,
      color: newProductForm.color,
      defaultShelfLifeHours: newProductForm.defaultShelfLifeHours,
      isDailyProduct: newProductForm.isDailyProduct,
      requiresThawing: newProductForm.requiresThawing,
      thawTimeHours: newProductForm.requiresThawing ? newProductForm.thawTimeHours : undefined,
      notes: newProductForm.notes || undefined,
      isActive: true,
      labelSize: newProductForm.labelSize
    };
    
    setProducts(prev => [...prev, newProduct]);
    setNewProductForm({
      name: '',
      category: 'meat',
      color: 'bg-red-500',
      defaultShelfLifeHours: 24,
      isDailyProduct: false,
      requiresThawing: false,
      thawTimeHours: 0,
      notes: '',
      labelSize: 'medium'
    });
    setShowAddProductDialog(false);
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    setShowEditProductDialog(false);
    setSelectedProduct(null);
  };

  // Inventory Management Functions
  const addInventoryItem = (inventoryData: Partial<InventoryItem>) => {
    const product = products.find(p => p.id === inventoryData.productId);
    if (!product) return;
    
    const receivedDate = inventoryData.receivedDate || new Date();
    const adjustedShelfLifeHours = getAdjustedShelfLife(product);
    const expiryDate = new Date(receivedDate.getTime() + adjustedShelfLifeHours * 60 * 60 * 1000);
    
    const newItem: InventoryItem = {
      id: `inv-${Date.now()}`,
      productId: inventoryData.productId!,
      restaurantId: currentUser?.restaurantId || restaurants[0]?.id || '',
      quantity: inventoryData.quantity!,
      receivedDate,
      expiryDate,
      status: 'fresh',
      batchNumber: inventoryData.batchNumber,
      isDaily: product.isDailyProduct,
      autoRenew: product.isDailyProduct,
      renewalHours: product.isDailyProduct ? adjustedShelfLifeHours : undefined
    };
    
    setInventory(prev => [...prev, newItem]);
    setShowAddInventoryDialog(false);
    
    // Auto-print label
    setTimeout(() => printLabel(newItem.id), 500);
  };

  // Printing Functions
  const printLabel = (inventoryItemId: string) => {
    const item = inventory.find(i => i.id === inventoryItemId);
    const product = products.find(p => p.id === item?.productId);
    const restaurant = restaurants.find(r => r.id === item?.restaurantId);
    
    if (!item || !product) return;
    
    const now = new Date();
    const thawDate = product.requiresThawing 
      ? new Date(now.getTime() + (product.thawTimeHours || 0) * 60 * 60 * 1000)
      : undefined;
    const wasteDate = new Date(item.expiryDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours after expiry
    
    const label: PrintLabel = {
      id: `label-${Date.now()}`,
      productName: product.name,
      quantity: item.quantity,
      thawDate,
      useByDate: item.expiryDate,
      wasteDate,
      restaurantName: restaurant?.name || 'McDonald\'s Restaurant',
      printedAt: now,
      labelSize: product.labelSize
    };
    
    setPrintQueue(prev => [...prev, label]);
  };

  // Message Functions
  const sendMessage = () => {
    if (!messageForm.subject || !messageForm.content) return;
    
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      fromUserId: currentUser?.id!,
      toUserId: messageForm.toUserId || undefined,
      toRole: messageForm.toRole,
      subject: messageForm.subject,
      content: messageForm.content,
      isRead: false,
      createdAt: new Date(),
      isSystemMessage: false
    };
    
    setMessages(prev => [...prev, newMessage]);
    setMessageForm({
      toUserId: '',
      toRole: undefined,
      subject: '',
      content: ''
    });
    setShowMessageDialog(false);
  };

  // Helper Functions
  const getCurrentUserRestaurants = () => {
    if (currentUser?.role === 'RFS') {
      return restaurants;
    } else if (currentUser?.role === 'OC') {
      return restaurants.filter(r => r.regionId === currentUser.regionId);
    } else if (currentUser?.role === 'RM') {
      return restaurants.filter(r => r.id === currentUser.restaurantId);
    }
    return [];
  };

  const getCurrentUserInventory = () => {
    const userRestaurants = getCurrentUserRestaurants();
    const restaurantIds = userRestaurants.map(r => r.id);
    return inventory.filter(item => restaurantIds.includes(item.restaurantId));
  };

  const getFilteredProducts = () => {
    let filtered = products.filter(p => p.isActive);
    
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (filterCategory !== 'all') {
      filtered = filtered.filter(p => p.category === filterCategory);
    }
    
    return filtered;
  };

  const getFilteredInventory = () => {
    let filtered = getCurrentUserInventory();
    
    if (searchTerm) {
      const productIds = products
        .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(p => p.id);
      filtered = filtered.filter(item => productIds.includes(item.productId));
    }
    
    if (filterStatus !== 'all') {
      filtered = filtered.filter(item => item.status === filterStatus);
    }
    
    return filtered;
  };

  const formatDateTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const getCategoryColor = (category: ProductCategory) => {
    const colors = {
      meat: 'bg-red-500',
      chicken: 'bg-orange-500',
      bakery: 'bg-amber-500',
      vegetables: 'bg-green-500',
      beverages: 'bg-blue-500',
      condiments: 'bg-purple-500',
      frozen: 'bg-cyan-500',
      dairy: 'bg-yellow-500',
      mccafe: 'bg-amber-700'
    };
    return colors[category];
  };

  const getStatusColor = (status: InventoryStatus) => {
    const colors = {
      fresh: 'bg-green-500',
      warning: 'bg-yellow-500',
      expired: 'bg-red-500'
    };
    return colors[status];
  };

  const getUnreadNotifications = () => {
    return notifications.filter(n => !n.isRead && n.userId === currentUser?.id).length;
  };

  const getUnreadMessages = () => {
    return messages.filter(m => 
      !m.isRead && 
      (m.toUserId === currentUser?.id || 
       (m.toRole === currentUser?.role && !m.toUserId))
    ).length;
  };

  const getUserMessages = () => {
    return messages.filter(m => 
      m.toUserId === currentUser?.id || 
      (m.toRole === currentUser?.role && !m.toUserId) ||
      m.fromUserId === currentUser?.id
    ).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  };

  const generateReport = (type: 'weekly' | 'monthly' | 'yearly') => {
    const userInventory = getCurrentUserInventory();
    const totalItems = userInventory.length;
    const freshItems = userInventory.filter(i => i.status === 'fresh').length;
    const expiredItems = userInventory.filter(i => i.status === 'expired').length;
    const wasteReduction = totalItems > 0 ? Math.round((freshItems / totalItems) * 100) : 0;
    const costSavings = wasteReduction * 100; // Example calculation
    const labelsPlinted = printQueue.length;

    return {
      totalItems,
      freshItems,
      expiredItems,
      wasteReduction,
      costSavings,
      labelsPlinted
    };
  };

  // Login Component (same as before)
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-2xl border-0">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 bg-primary rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-primary-foreground">M</span>
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-primary">McDonald's</CardTitle>
              <CardDescription className="text-base mt-2">
                Inventory Management System
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter your password"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            {loginError && (
              <Alert className="border-destructive bg-destructive/10">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-destructive">
                  {loginError}
                </AlertDescription>
              </Alert>
            )}
            <Button 
              onClick={handleLogin} 
              className="w-full bg-primary hover:bg-primary/90"
              size="lg"
            >
              Sign In
            </Button>
            <div className="text-xs text-muted-foreground text-center space-y-1">
              <p><strong>System Owner (RFS):</strong> RFS / RFS@PC123</p>
              <p><strong>Demo OC:</strong> OC001 / OC123</p>
              <p><strong>Demo RM:</strong> RM001 / RM123</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main Dashboard Component
  return (
    <div className="min-h-screen bg-background">
      {/* Header (same as before) */}
      <header className="bg-white border-b border-border shadow-sm">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <span className="text-lg font-bold text-primary-foreground">M</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary">McDonald's Inventory</h1>
              <p className="text-sm text-muted-foreground">
                {formatDateTime(currentDateTime)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 md:space-x-4">
            {/* Mobile Seasonal Status Indicator */}
            <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-50 to-green-50 px-2 py-1 rounded-lg border text-xs">
              <div className="flex items-center space-x-1">
                <CalendarIcon className="h-3 w-3 text-blue-600" />
                <span className="font-medium text-blue-800 capitalize">{seasonalSettings.currentSeason}</span>
              </div>
              {seasonalSettings.adjustments.filter(adj => 
                adj.isActive && 
                adj.season === seasonalSettings.currentSeason && 
                (currentUser.role === 'RM' ? 
                  (adj.category === 'dairy' || adj.category === 'vegetables' || adj.category === 'meat' || adj.category === 'chicken') : true)
              ).length > 0 && (
                <Badge className="bg-orange-100 text-orange-800 text-xs px-1 py-0 h-4">
                  {seasonalSettings.adjustments.filter(adj => 
                    adj.isActive && 
                    adj.season === seasonalSettings.currentSeason
                  ).length} active
                </Badge>
              )}
            </div>
            
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium">{currentUser.name}</p>
              <p className="text-xs text-muted-foreground">
                {currentUser.role === 'RFS' && 'System Administrator'}
                {currentUser.role === 'OC' && 'Operations Consultant'}
                {currentUser.role === 'RM' && 'Restaurant Manager'}
                {currentUser.restaurantId && ` - ${restaurants.find(r => r.id === currentUser.restaurantId)?.name}`}
              </p>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-4 w-4" />
                {getUnreadNotifications() > 0 && (
                  <Badge className="absolute -top-2 -right-2 px-1 min-w-[1.25rem] h-5">
                    {getUnreadNotifications()}
                  </Badge>
                )}
              </Button>
              
              <Button variant="ghost" size="sm" className="relative">
                <MessageSquare className="h-4 w-4" />
                {getUnreadMessages() > 0 && (
                  <Badge className="absolute -top-2 -right-2 px-1 min-w-[1.25rem] h-5">
                    {getUnreadMessages()}
                  </Badge>
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex">
        {/* Sidebar Navigation (same as before) */}
        <aside className="w-64 bg-card border-r border-border h-[calc(100vh-4rem)]">
          <nav className="p-4 space-y-2">
            <Button 
              variant={activeTab === 'dashboard' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('dashboard')}
            >
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
            
            <Button 
              variant={activeTab === 'inventory' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('inventory')}
            >
              <Package className="h-4 w-4 mr-2" />
              Inventory
            </Button>
            
            {currentUser.role === 'RM' && (
              <Button 
                variant={activeTab === 'daily-products' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('daily-products')}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Daily Products
              </Button>
            )}
            
            <Button 
              variant={activeTab === 'printing' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('printing')}
            >
              <Printer className="h-4 w-4 mr-2" />
              Label Printing
            </Button>
            
            <Button 
              variant={activeTab === 'reports' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('reports')}
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Reports
            </Button>
            
            <Button 
              variant={activeTab === 'messages' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('messages')}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
              {getUnreadMessages() > 0 && (
                <Badge className="ml-auto px-1 min-w-[1.25rem] h-5">
                  {getUnreadMessages()}
                </Badge>
              )}
            </Button>
            
            {(currentUser.role === 'RFS' || currentUser.role === 'OC') && (
              <Button 
                variant={activeTab === 'users' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('users')}
              >
                <Users className="h-4 w-4 mr-2" />
                User Management
              </Button>
            )}
            
            {currentUser.role === 'RFS' && (
              <Button 
                variant={activeTab === 'products' ? 'default' : 'ghost'} 
                className="w-full justify-start"
                onClick={() => setActiveTab('products')}
              >
                <Package className="h-4 w-4 mr-2" />
                Product Catalog
              </Button>
            )}
            
            <Button 
              variant={activeTab === 'settings' ? 'default' : 'ghost'} 
              className="w-full justify-start"
              onClick={() => setActiveTab('settings')}
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-6 overflow-auto h-[calc(100vh-4rem)]">
          {/* Dashboard Tab (previous implementation) */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Dashboard</h2>
                <div className="flex space-x-2">
                  {currentUser.role === 'RM' && (
                    <Button onClick={() => setShowAddInventoryDialog(true)}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Inventory
                    </Button>
                  )}
                </div>
              </div>

              {/* Mobile Seasonal Impact Summary - Only on Mobile */}
              <div className="block md:hidden mb-6">
                <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-0">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-green-500 mr-2"></div>
                        <h3 className="text-lg font-semibold text-gray-800">Seasonal Impact</h3>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-blue-600 capitalize">{seasonalSettings.currentSeason}</p>
                        <p className="text-xs text-gray-500">
                          {seasonalSettings.autoDetectSeason ? 'Auto-detected' : 'Manual'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div className="bg-white rounded-lg p-3">
                        <p className="text-xs text-gray-500 mb-1">Active Adjustments</p>
                        <p className="text-lg font-bold text-blue-600">
                          {seasonalSettings.adjustments.filter(adj => 
                            adj.isActive && adj.season === seasonalSettings.currentSeason
                          ).length}
                        </p>
                      </div>
                      <div className="bg-white rounded-lg p-3">
                        <p className="text-xs text-gray-500 mb-1">Affected Categories</p>
                        <p className="text-lg font-bold text-green-600">
                          {new Set(seasonalSettings.adjustments
                            .filter(adj => adj.isActive && adj.season === seasonalSettings.currentSeason)
                            .map(adj => adj.category)
                          ).size}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center text-xs text-gray-600">
                      <div className="w-2 h-2 rounded-full bg-yellow-400 mr-2"></div>
                      <span>Shelf life automatically adjusted for {seasonalSettings.currentSeason} conditions</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Mobile Quick Actions - Only on Mobile */}
              {currentUser.role === 'RM' && (
                <div className="block md:hidden mb-6">
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      onClick={() => setShowAddInventoryDialog(true)}
                      className="h-12 bg-red-600 hover:bg-red-700 text-white shadow-lg"
                      size="lg"
                    >
                      <Plus className="h-5 w-5 mr-2" />
                      Add Inventory
                    </Button>
                    <Button 
                      onClick={() => setActiveTab('daily')}
                      variant="outline"
                      className="h-12 border-yellow-400 text-yellow-600 hover:bg-yellow-50 shadow-lg"
                      size="lg"
                    >
                      <Clock className="h-5 w-5 mr-2" />
                      Daily Products
                    </Button>
                  </div>
                </div>
              )}

              {/* Mobile Seasonal Quick Stats - Only on Mobile */}
              <div className="block md:hidden mb-6">
                <div className="grid grid-cols-2 gap-3">
                  <Card className="bg-orange-50 border-orange-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs font-medium text-orange-600">Shortened Items</p>
                          <p className="text-xl font-bold text-orange-700">
                            {products.filter(product => {
                              const adjustedHours = getAdjustedShelfLife(product);
                              return adjustedHours < product.defaultShelfLifeHours;
                            }).length}
                          </p>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-orange-200 flex items-center justify-center">
                          <TrendingDown className="h-4 w-4 text-orange-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-emerald-50 border-emerald-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs font-medium text-emerald-600">Extended Items</p>
                          <p className="text-xl font-bold text-emerald-700">
                            {products.filter(product => {
                              const adjustedHours = getAdjustedShelfLife(product);
                              return adjustedHours > product.defaultShelfLifeHours;
                            }).length}
                          </p>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-emerald-200 flex items-center justify-center">
                          <TrendingUp className="h-4 w-4 text-emerald-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Mobile Most Impacted Products - Only on Mobile */}
              <div className="block md:hidden mb-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <Activity className="h-5 w-5 mr-2 text-blue-600" />
                      Most Impacted Products
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      {products
                        .map(product => {
                          const originalHours = product.defaultShelfLifeHours;
                          const adjustedHours = getAdjustedShelfLife(product);
                          const changePercent = Math.round(((adjustedHours - originalHours) / originalHours) * 100);
                          return { ...product, originalHours, adjustedHours, changePercent };
                        })
                        .filter(p => p.changePercent !== 0)
                        .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
                        .slice(0, 4)
                        .map(product => (
                          <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center">
                              <div 
                                className="w-3 h-3 rounded-full mr-3" 
                                style={{ backgroundColor: product.color }}
                              ></div>
                              <div>
                                <p className="font-medium text-sm">{product.name}</p>
                                <p className="text-xs text-gray-500">
                                  {product.originalHours}h → {product.adjustedHours}h
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                product.changePercent > 0 
                                  ? 'bg-emerald-100 text-emerald-700' 
                                  : 'bg-orange-100 text-orange-700'
                              }`}>
                                {product.changePercent > 0 ? '+' : ''}{product.changePercent}%
                              </div>
                            </div>
                          </div>
                        ))
                      }
                      {products.filter(p => {
                        const adjustedHours = getAdjustedShelfLife(p);
                        return adjustedHours !== p.defaultShelfLifeHours;
                      }).length === 0 && (
                        <p className="text-center text-gray-500 py-4 text-sm">
                          No seasonal adjustments active
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Desktop Stats Cards - Hidden on Mobile */}
              <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Package className="h-8 w-8 text-primary" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Total Items</p>
                        <p className="text-2xl font-bold">{getCurrentUserInventory().length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <CheckCircle className="h-8 w-8 text-green-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Fresh Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'fresh').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <AlertTriangle className="h-8 w-8 text-yellow-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Warning Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'warning').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <XCircle className="h-8 w-8 text-red-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Expired Items</p>
                        <p className="text-2xl font-bold">
                          {getCurrentUserInventory().filter(i => i.status === 'expired').length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity & Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Expiring Soon */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
                      Expiring Soon (30 minutes)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {getCurrentUserInventory()
                        .filter(item => item.status === 'warning')
                        .map(item => {
                          const product = products.find(p => p.id === item.productId);
                          return (
                            <div key={item.id} className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                              <div>
                                <p className="font-medium">{product?.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  Expires: {formatDateTime(item.expiryDate)}
                                </p>
                              </div>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => printLabel(item.id)}
                              >
                                <Printer className="h-4 w-4" />
                              </Button>
                            </div>
                          );
                        })
                      }
                      {getCurrentUserInventory().filter(item => item.status === 'warning').length === 0 && (
                        <p className="text-muted-foreground text-center py-4">No items expiring soon</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Notifications */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bell className="h-5 w-5 mr-2" />
                      Recent Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {notifications
                        .filter(n => n.userId === currentUser.id)
                        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
                        .slice(0, 5)
                        .map(notification => (
                          <div key={notification.id} className="p-2 bg-muted/50 rounded">
                            <p className="font-medium text-sm">{notification.title}</p>
                            <p className="text-xs text-muted-foreground">{notification.message}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatDateTime(notification.createdAt)}
                            </p>
                          </div>
                        ))
                      }
                      {notifications.filter(n => n.userId === currentUser.id).length === 0 && (
                        <p className="text-muted-foreground text-center py-4">No notifications</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Inventory Tab (previous implementation) */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Inventory Management</h2>
                {currentUser.role === 'RM' && (
                  <Button onClick={() => setShowAddInventoryDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                )}
              </div>

              {/* Search and Filters */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as any)}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="fresh">Fresh</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Mobile Inventory Cards */}
              <div className="block md:hidden">
                <div className="grid gap-4">
                  {getFilteredInventory().map(item => {
                    const product = products.find(p => p.id === item.productId);
                    const adjustedHours = product ? getAdjustedShelfLife(product) : 0;
                    const isSeasonallyAdjusted = product && adjustedHours !== product.defaultShelfLifeHours;
                    
                    return (
                      <Card key={item.id} className="p-4">
                        <div className="space-y-3">
                          {/* Product Header */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div className={`w-4 h-4 rounded-full ${product?.color || 'bg-gray-400'}`} />
                              <div>
                                <div className="font-medium text-sm">{product?.name}</div>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className={`text-xs ${getCategoryColor(product?.category || 'meat')}`}>
                                    {product?.category}
                                  </Badge>
                                  {isSeasonallyAdjusted && (
                                    <Badge className="bg-orange-100 text-orange-800 text-xs px-2 py-0 h-5">
                                      🌡️ {adjustedHours}h
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                            <Badge className={getStatusColor(item.status)}>
                              {item.status}
                            </Badge>
                          </div>
                          
                          {/* Item Details */}
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            <div>
                              <span className="text-muted-foreground">Quantity:</span>
                              <div className="font-medium">{item.quantity}</div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Received:</span>
                              <div className="font-medium text-xs">{formatDateTime(item.receivedDate)}</div>
                            </div>
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Expires:</span>
                              <div className={`font-medium text-xs ${
                                item.status === 'expired' ? 'text-red-600' : 
                                item.status === 'warning' ? 'text-orange-600' : 'text-green-600'
                              }`}>
                                {formatDateTime(item.expiryDate)}
                                {isSeasonallyAdjusted && (
                                  <span className="text-orange-600 ml-1">({seasonalSettings.currentSeason} adjusted)</span>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          {/* Actions */}
                          <div className="flex space-x-2 pt-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="flex-1 h-10"
                              onClick={() => printLabel(item.id)}
                            >
                              <Printer className="h-4 w-4 mr-2" />
                              Print Label
                            </Button>
                            {currentUser.role === 'RM' && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="h-10 px-3"
                                onClick={() => {
                                  setInventory(prev => prev.filter(i => i.id !== item.id));
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                  
                  {getFilteredInventory().length === 0 && (
                    <div className="text-center py-12 text-muted-foreground">
                      <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No inventory items found</p>
                      <p className="text-sm">Add items or adjust your filters</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Desktop Inventory Table */}
              <div className="hidden md:block">
                <Card>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Received</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getFilteredInventory().map(item => {
                        const product = products.find(p => p.id === item.productId);
                        return (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div className="flex items-center space-x-2">
                                <div className={`w-3 h-3 rounded-full ${product?.color || 'bg-gray-400'}`} />
                                <div className="flex flex-col">
                                  <span className="font-medium">{product?.name}</span>
                                  {(() => {
                                    if (!product) return null;
                                    const adjustedHours = getAdjustedShelfLife(product);
                                    const isAdjusted = adjustedHours !== product.defaultShelfLifeHours;
                                    return isAdjusted ? (
                                      <span className="text-xs text-orange-600 flex items-center gap-1">
                                        🌡️ {adjustedHours}h ({seasonalSettings.currentSeason})
                                      </span>
                                    ) : null;
                                  })()} 
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={getCategoryColor(product?.category || 'meat')}>
                                {product?.category}
                              </Badge>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{formatDateTime(item.receivedDate)}</TableCell>
                            <TableCell>{formatDateTime(item.expiryDate)}</TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(item.status)}>
                                {item.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-1">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => printLabel(item.id)}
                                >
                                  <Printer className="h-4 w-4" />
                                </Button>
                                {currentUser.role === 'RM' && (
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      setInventory(prev => prev.filter(i => i.id !== item.id));
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                  
                  {getFilteredInventory().length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No inventory items found
                    </div>
                  )}
                </CardContent>
              </Card>
              </div>
            </div>
          )}

          {/* Daily Products Tab */}
          {activeTab === 'daily-products' && currentUser.role === 'RM' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Daily Products Management</h2>
                <Button onClick={() => setShowAddInventoryDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Daily Item
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {products
                  .filter(p => p.isDailyProduct && p.isActive)
                  .map(product => {
                    const dailyItems = getCurrentUserInventory().filter(
                      item => item.productId === product.id && item.isDaily
                    );
                    
                    return (
                      <Card key={product.id}>
                        <CardHeader>
                          <CardTitle className="flex items-center space-x-2">
                            <div className={`w-4 h-4 rounded-full ${product.color}`} />
                            <span>{product.name}</span>
                          </CardTitle>
                          <CardDescription className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span>Shelf Life: {product.defaultShelfLifeHours} hours</span>
                              {(() => {
                                const adjustedHours = getAdjustedShelfLife(product);
                                const isAdjusted = adjustedHours !== product.defaultShelfLifeHours;
                                return isAdjusted ? (
                                  <Badge className="bg-orange-100 text-orange-800 text-xs px-2 py-0 h-5">
                                    🌡️ {adjustedHours}h ({seasonalSettings.currentSeason})
                                  </Badge>
                                ) : null;
                              })()} 
                            </div>
                            {product.notes && (
                              <div className="text-xs text-muted-foreground">{product.notes}</div>
                            )}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="text-sm">
                              <strong>Active Items:</strong> {dailyItems.length}
                            </div>
                            
                            {dailyItems.map(item => (
                              <div key={item.id} className="p-2 bg-muted/50 rounded">
                                <div className="flex justify-between items-center">
                                  <span>Qty: {item.quantity}</span>
                                  <Badge className={getStatusColor(item.status)}>
                                    {item.status}
                                  </Badge>
                                </div>
                                <div className="text-xs text-muted-foreground mt-1">
                                  Expires: {formatDateTime(item.expiryDate)}
                                </div>
                                <div className="flex space-x-1 mt-2">
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => printLabel(item.id)}
                                  >
                                    <Printer className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      // Auto-renew: create new item with fresh expiry using seasonal adjustments
                                      const adjustedShelfLifeHours = getAdjustedShelfLife(product);
                                      const newItem: InventoryItem = {
                                        ...item,
                                        id: `inv-${Date.now()}`,
                                        receivedDate: new Date(),
                                        expiryDate: new Date(Date.now() + adjustedShelfLifeHours * 60 * 60 * 1000),
                                        status: 'fresh'
                                      };
                                      setInventory(prev => [...prev, newItem]);
                                      printLabel(newItem.id);
                                    }}
                                  >
                                    <RefreshCw className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => {
                                      setInventory(prev => prev.filter(i => i.id !== item.id));
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                            
                            {dailyItems.length === 0 && (
                              <p className="text-sm text-muted-foreground">No active items</p>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                }
              </div>
            </div>
          )}

          {/* Printing Tab */}
          {activeTab === 'printing' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Label Printing System</h2>
                <div className="flex space-x-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export Queue
                  </Button>
                  <Button>
                    <Printer className="h-4 w-4 mr-2" />
                    Print All ({printQueue.length})
                  </Button>
                </div>
              </div>

              {/* Printer Status */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Printer className="h-5 w-5 mr-2" />
                      Printer Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full" />
                        <span className="text-sm">EPSON TM-T20III Connected</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Paper Level: 85%
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Last Maintenance: 2 days ago
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Today's Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Labels Printed:</span>
                        <span className="font-medium">{printQueue.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Auto-Prints:</span>
                        <span className="font-medium">{Math.floor(printQueue.length * 0.7)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Manual Prints:</span>
                        <span className="font-medium">{Math.floor(printQueue.length * 0.3)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Label Sizes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Small (2"×1"):</span>
                        <span className="font-medium">{printQueue.filter(l => l.labelSize === 'small').length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Medium (3"×2"):</span>
                        <span className="font-medium">{printQueue.filter(l => l.labelSize === 'medium').length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Large (4"×3"):</span>
                        <span className="font-medium">{printQueue.filter(l => l.labelSize === 'large').length}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Print Jobs */}
              <Card>
                <CardHeader>
                  <CardTitle>Print Queue & History</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Quantity</TableHead>
                        <TableHead>Thaw Date</TableHead>
                        <TableHead>Use By</TableHead>
                        <TableHead>Waste Date</TableHead>
                        <TableHead>Size</TableHead>
                        <TableHead>Printed</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {printQueue
                        .sort((a, b) => b.printedAt.getTime() - a.printedAt.getTime())
                        .slice(0, 20)
                        .map(label => (
                          <TableRow key={label.id}>
                            <TableCell className="font-medium">{label.productName}</TableCell>
                            <TableCell>{label.quantity}</TableCell>
                            <TableCell>
                              {label.thawDate ? formatDateTime(label.thawDate) : 'N/A'}
                            </TableCell>
                            <TableCell>{formatDateTime(label.useByDate)}</TableCell>
                            <TableCell>{formatDateTime(label.wasteDate)}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{label.labelSize}</Badge>
                            </TableCell>
                            <TableCell>{formatDateTime(label.printedAt)}</TableCell>
                            <TableCell>
                              <div className="flex space-x-1">
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Printer className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      }
                    </TableBody>
                  </Table>
                  
                  {printQueue.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No print jobs found
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Label Preview */}
              <Card>
                <CardHeader>
                  <CardTitle>Label Format Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Small Label */}
                    <div className="p-4 border-2 border-dashed border-gray-300 bg-white rounded">
                      <div className="text-center">
                        <h4 className="font-bold text-xs">SMALL LABEL (2"×1")</h4>
                        <div className="mt-2 p-2 bg-gray-50 border text-xs">
                          <div className="font-bold">CAESAR SALAD MIX</div>
                          <div>QTY: 5</div>
                          <div>USE BY: 02/15 14:30</div>
                          <div>WASTE: 02/15 16:30</div>
                          <div className="text-xs">McDonald's Downtown</div>
                        </div>
                      </div>
                    </div>

                    {/* Medium Label */}
                    <div className="p-4 border-2 border-dashed border-gray-300 bg-white rounded">
                      <div className="text-center">
                        <h4 className="font-bold text-xs">MEDIUM LABEL (3"×2")</h4>
                        <div className="mt-2 p-3 bg-gray-50 border text-sm">
                          <div className="font-bold">BEEF PATTIES 4:1</div>
                          <div>QTY: 10 lbs</div>
                          <div>THAW: 02/14 08:00</div>
                          <div>USE BY: 02/15 08:00</div>
                          <div>WASTE: 02/15 10:00</div>
                          <div className="text-xs mt-1">McDonald's Downtown</div>
                          <div className="text-xs">Printed: 02/13 16:45</div>
                        </div>
                      </div>
                    </div>

                    {/* Large Label */}
                    <div className="p-4 border-2 border-dashed border-gray-300 bg-white rounded">
                      <div className="text-center">
                        <h4 className="font-bold text-xs">LARGE LABEL (4"×3")</h4>
                        <div className="mt-2 p-4 bg-gray-50 border">
                          <div className="font-bold text-lg">BIG MAC BUNS</div>
                          <div className="text-sm">QTY: 24 pieces</div>
                          <div className="text-sm">USE BY: 02/15 08:00</div>
                          <div className="text-sm">WASTE: 02/15 10:00</div>
                          <div className="text-xs mt-2">McDonald's Downtown</div>
                          <div className="text-xs">Batch: BMB240214001</div>
                          <div className="text-xs">Printed: 02/13 16:45</div>
                          <div className="text-xs mt-1 font-mono">*||||||||||*</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Reports Tab */}
          {activeTab === 'reports' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Reports & Analytics</h2>
                <div className="flex space-x-2">
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export Reports
                  </Button>
                  <Button>
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </div>
              </div>

              {/* Report Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <TrendingUp className="h-8 w-8 text-green-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Waste Reduction</p>
                        <p className="text-2xl font-bold">15%</p>
                        <p className="text-xs text-green-600">↑ 3% from last month</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Package className="h-8 w-8 text-blue-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Items Processed</p>
                        <p className="text-2xl font-bold">{getCurrentUserInventory().length}</p>
                        <p className="text-xs text-blue-600">This week</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Printer className="h-8 w-8 text-purple-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Labels Printed</p>
                        <p className="text-2xl font-bold">{printQueue.length}</p>
                        <p className="text-xs text-purple-600">Today</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <TrendingDown className="h-8 w-8 text-orange-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Cost Savings</p>
                        <p className="text-2xl font-bold">$2,450</p>
                        <p className="text-xs text-orange-600">This month</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Report Tabs */}
              <Tabs defaultValue="weekly" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="weekly">Weekly Reports</TabsTrigger>
                  <TabsTrigger value="monthly">Monthly Reports</TabsTrigger>
                  <TabsTrigger value="yearly">Yearly Reports</TabsTrigger>
                </TabsList>
                
                <TabsContent value="weekly" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Weekly Inventory Performance</CardTitle>
                      <CardDescription>Feb 12 - Feb 18, 2024</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold">{getCurrentUserInventory().length}</div>
                          <div className="text-sm text-muted-foreground">Total Items</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">{getCurrentUserInventory().filter(i => i.status === 'fresh').length}</div>
                          <div className="text-sm text-muted-foreground">Fresh Items</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-red-600">{getCurrentUserInventory().filter(i => i.status === 'expired').length}</div>
                          <div className="text-sm text-muted-foreground">Expired Items</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">{printQueue.length}</div>
                          <div className="text-sm text-muted-foreground">Labels Printed</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="monthly" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Monthly Performance Summary</CardTitle>
                      <CardDescription>February 2024</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span>Waste Reduction Target:</span>
                          <span className="font-bold">15%</span>
                        </div>
                        <Progress value={85} className="w-full" />
                        <div className="text-sm text-green-600">85% of monthly target achieved</div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="yearly" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Annual Performance Review</CardTitle>
                      <CardDescription>2024 Year-to-Date</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-green-50 rounded">
                          <div className="text-3xl font-bold text-green-600">$125,000</div>
                          <div className="text-sm text-green-600">Cost Savings Target</div>
                        </div>
                        <div className="text-center p-4 bg-blue-50 rounded">
                          <div className="text-3xl font-bold text-blue-600">99.8%</div>
                          <div className="text-sm text-blue-600">System Uptime</div>
                        </div>
                        <div className="text-center p-4 bg-purple-50 rounded">
                          <div className="text-3xl font-bold text-purple-600">92%</div>
                          <div className="text-sm text-purple-600">Waste Prevention</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Messages Tab */}
          {activeTab === 'messages' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Messages & Communication</h2>
                <Button onClick={() => setShowMessageDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  New Message
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Message List */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Recent Messages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {getUserMessages().map(message => {
                        const sender = users.find(u => u.id === message.fromUserId);
                        const isUnread = !message.isRead && 
                          (message.toUserId === currentUser.id || 
                           (message.toRole === currentUser.role && !message.toUserId));
                        
                        return (
                          <div key={message.id} className={`p-3 rounded border ${
                            isUnread ? 'bg-blue-50 border-blue-200' : 'bg-white'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-2">
                                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                                  <span className="text-xs font-bold text-primary-foreground">
                                    {sender?.name.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div>
                                  <div className="font-medium text-sm">{sender?.name}</div>
                                  <div className="text-xs text-muted-foreground">
                                    {sender?.role} • {formatDateTime(message.createdAt)}
                                  </div>
                                </div>
                              </div>
                              {isUnread && (
                                <Badge className="bg-blue-500">New</Badge>
                              )}
                            </div>
                            <div className="font-medium text-sm mb-1">{message.subject}</div>
                            <div className="text-sm text-muted-foreground">
                              {message.content.length > 100 
                                ? `${message.content.substring(0, 100)}...` 
                                : message.content
                              }
                            </div>
                            <div className="flex space-x-2 mt-2">
                              <Button size="sm" variant="outline"
                                onClick={() => {
                                  setMessages(prev => prev.map(m => 
                                    m.id === message.id ? { ...m, isRead: true } : m
                                  ));
                                }}
                              >
                                <Mail className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                      
                      {getUserMessages().length === 0 && (
                        <p className="text-muted-foreground text-center py-8">No messages found</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full" onClick={() => setShowMessageDialog(true)}>
                      <Send className="h-4 w-4 mr-2" />
                      Send Message
                    </Button>
                    
                    {currentUser.role !== 'RM' && (
                      <Button variant="outline" className="w-full"
                        onClick={() => {
                          setMessageForm({ ...messageForm, toRole: 'RM' });
                          setShowMessageDialog(true);
                        }}
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Broadcast to RMs
                      </Button>
                    )}
                    
                    {currentUser.role === 'RFS' && (
                      <Button variant="outline" className="w-full"
                        onClick={() => {
                          setMessageForm({ ...messageForm, toRole: 'OC' });
                          setShowMessageDialog(true);
                        }}
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Broadcast to OCs
                      </Button>
                    )}
                    
                    <div className="text-sm text-muted-foreground mt-4">
                      <p><strong>Unread:</strong> {getUnreadMessages()}</p>
                      <p><strong>Total:</strong> {getUserMessages().length}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* User Management Tab */}
          {(activeTab === 'users' && (currentUser.role === 'RFS' || currentUser.role === 'OC')) && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">User Management</h2>
                <Button onClick={() => setShowCreateUserDialog(true)}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add User
                </Button>
              </div>

              {/* User Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Shield className="h-8 w-8 text-red-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">System Admins</p>
                        <p className="text-2xl font-bold">{users.filter(u => u.role === 'RFS').length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Building className="h-8 w-8 text-blue-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Operations Consultants</p>
                        <p className="text-2xl font-bold">{users.filter(u => u.role === 'OC').length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <Store className="h-8 w-8 text-green-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Restaurant Managers</p>
                        <p className="text-2xl font-bold">{users.filter(u => u.role === 'RM').length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center">
                      <UserCheck className="h-8 w-8 text-purple-500" />
                      <div className="ml-4">
                        <p className="text-sm font-medium text-muted-foreground">Active Users</p>
                        <p className="text-2xl font-bold">{users.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Users Table */}
              <Card>
                <CardHeader>
                  <CardTitle>System Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Region/Restaurant</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users
                        .filter(user => {
                          if (currentUser.role === 'RFS') return true;
                          if (currentUser.role === 'OC') {
                            return user.regionId === currentUser.regionId || user.role === 'RM';
                          }
                          return false;
                        })
                        .map(user => {
                          const region = regions.find(r => r.id === user.regionId);
                          const restaurant = restaurants.find(r => r.id === user.restaurantId);
                          
                          return (
                            <TableRow key={user.id}>
                              <TableCell className="font-medium">{user.name}</TableCell>
                              <TableCell>{user.username}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className={
                                  user.role === 'RFS' ? 'border-red-500 text-red-700' :
                                  user.role === 'OC' ? 'border-blue-500 text-blue-700' :
                                  'border-green-500 text-green-700'
                                }>
                                  {user.role}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {user.role === 'OC' && region && region.name}
                                {user.role === 'RM' && restaurant && restaurant.name}
                                {user.role === 'RFS' && 'System Wide'}
                              </TableCell>
                              <TableCell>{formatDateTime(user.createdAt)}</TableCell>
                              <TableCell>
                                <div className="flex space-x-1">
                                  <Button size="sm" variant="outline">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  {user.id !== currentUser.id && (
                                    <Button size="sm" variant="outline">
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      }
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Product Catalog Tab */}
          {(activeTab === 'products' && currentUser.role === 'RFS') && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Product Catalog Management</h2>
                <Button onClick={() => setShowAddProductDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </div>

              {/* Product Categories */}
              <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-9 gap-2">
                {(['all', 'meat', 'chicken', 'bakery', 'vegetables', 'beverages', 'condiments', 'frozen', 'dairy', 'mccafe'] as const).map(category => (
                  <Button
                    key={category}
                    variant={filterCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setFilterCategory(category as ProductCategory | 'all')}
                    className="capitalize"
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {/* Search */}
              <div className="relative max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {getFilteredProducts().map(product => (
                  <Card key={product.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <div className={`w-4 h-4 rounded-full ${product.color}`} />
                        <span className="text-sm">{product.name}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className={getCategoryColor(product.category)}>
                            {product.category}
                          </Badge>
                          <Badge variant={product.isDailyProduct ? 'default' : 'secondary'} className="text-xs">
                            {product.isDailyProduct ? 'Daily' : 'Regular'}
                          </Badge>
                        </div>
                        
                        <div className="text-sm space-y-1">
                          <div>Shelf Life: {product.defaultShelfLifeHours}h</div>
                          {product.requiresThawing && (
                            <div>Thaw Time: {product.thawTimeHours}h</div>
                          )}
                          <div>Label Size: {product.labelSize}</div>
                        </div>
                        
                        {product.notes && (
                          <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
                            {product.notes}
                          </div>
                        )}
                        
                        <div className="flex space-x-1 mt-3">
                          <Button size="sm" variant="outline" className="flex-1"
                            onClick={() => {
                              console.log('Editing product:', product.id);
                              setSelectedProduct({...product});
                              setShowEditProductDialog(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline"
                            onClick={() => {
                              setProducts(prev => prev.map(p => 
                                p.id === product.id ? { ...p, isActive: !p.isActive } : p
                              ));
                            }}
                          >
                            {product.isActive ? <Archive className="h-4 w-4" /> : <Package className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">System Settings</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                {/* Printer Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Thermal Printer Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Printer Model</Label>
                      <Select defaultValue="epson-tm-t20iii">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="epson-tm-t20iii">EPSON TM-T20III</SelectItem>
                          <SelectItem value="epson-tm-t88vi">EPSON TM-T88VI</SelectItem>
                          <SelectItem value="zebra-gk420t">Zebra GK420t</SelectItem>
                          <SelectItem value="brother-ql-820nwb">Brother QL-820NWB</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Paper Width</Label>
                      <Select defaultValue="80mm">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="58mm">58mm</SelectItem>
                          <SelectItem value="80mm">80mm</SelectItem>
                          <SelectItem value="110mm">110mm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Auto-print on expiration warnings</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Print queue enabled</Label>
                    </div>
                  </CardContent>
                </Card>

                {/* Notification Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle>Notification Preferences</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Expiration Warning Time</Label>
                      <Select defaultValue="30">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 minutes</SelectItem>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="120">2 hours</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Email notifications</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Sound alerts</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Daily summary reports</Label>
                    </div>
                  </CardContent>
                </Card>

                {/* System Information */}
                <Card>
                  <CardHeader>
                    <CardTitle>System Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Version:</span>
                      <span className="text-sm font-medium">v2.1.0</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Last Updated:</span>
                      <span className="text-sm font-medium">Feb 14, 2024</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Database:</span>
                      <span className="text-sm font-medium">Connected</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Uptime:</span>
                      <span className="text-sm font-medium">99.8%</span>
                    </div>
                    <Separator className="my-4" />
                    <Button variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Export System Logs
                    </Button>
                  </CardContent>
                </Card>

                {/* User Preferences */}
                <Card>
                  <CardHeader>
                    <CardTitle>User Preferences</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Time Format</Label>
                      <Select defaultValue="12h">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="12h">12-hour (AM/PM)</SelectItem>
                          <SelectItem value="24h">24-hour</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Date Format</Label>
                      <Select defaultValue="mdy">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mdy">MM/DD/YYYY</SelectItem>
                          <SelectItem value="dmy">DD/MM/YYYY</SelectItem>
                          <SelectItem value="ymd">YYYY-MM-DD</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Language</Label>
                      <Select defaultValue="en">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="ar">العربية</SelectItem>
                          <SelectItem value="fr">Français</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Seasonal Adjustments */}
                {currentUser?.role === 'RFS' && (
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CalendarIcon className="h-5 w-5" />
                        Seasonal Adjustments
                      </CardTitle>
                      <CardDescription>
                        Automatically adjust shelf life times based on seasonal temperature variations for optimal food safety
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Current Season & Auto-Detection */}
                      <div className="p-3 md:p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                          <div className="space-y-1">
                            <div className="font-semibold text-base md:text-lg capitalize">
                              Current Season: {seasonalSettings.currentSeason}
                            </div>
                            <div className="text-xs md:text-sm text-gray-600">
                              {seasonalSettings.autoDetectSeason ? 'Auto-detected based on calendar' : 'Manually set'}
                            </div>
                          </div>
                          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                            <div className="flex items-center space-x-2">
                              <Switch 
                                checked={seasonalSettings.autoDetectSeason}
                                onCheckedChange={(checked) => 
                                  updateSeasonalSettings({ autoDetectSeason: checked })
                                }
                              />
                              <Label className="text-sm">Auto-detect</Label>
                            </div>
                            {!seasonalSettings.autoDetectSeason && (
                              <Select 
                                value={seasonalSettings.currentSeason} 
                                onValueChange={(season: Season) => 
                                  updateSeasonalSettings({ currentSeason: season })
                                }
                              >
                                <SelectTrigger className="w-full sm:w-32">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="summer">Summer</SelectItem>
                                  <SelectItem value="winter">Winter</SelectItem>
                                  <SelectItem value="spring">Spring</SelectItem>
                                  <SelectItem value="autumn">Autumn</SelectItem>
                                </SelectContent>
                              </Select>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Active Adjustments */}
                      <div className="space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                          <h4 className="font-semibold mb-2 sm:mb-0">Current Season Adjustments</h4>
                          <Button 
                            size="sm" 
                            onClick={() => setShowAddSeasonalAdjustmentDialog(true)}
                            className="w-full sm:w-auto"
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Add Adjustment
                          </Button>
                        </div>
                        
                        <div className="grid gap-3">
                          {seasonalSettings.adjustments
                            .filter(adj => adj.season === seasonalSettings.currentSeason)
                            .map(adjustment => {
                              const categoryColor = {
                                'meat': 'bg-red-100 text-red-800',
                                'chicken': 'bg-orange-100 text-orange-800', 
                                'dairy': 'bg-blue-100 text-blue-800',
                                'vegetables': 'bg-green-100 text-green-800',
                                'bakery': 'bg-yellow-100 text-yellow-800',
                                'all': 'bg-gray-100 text-gray-800'
                              }[adjustment.category] || 'bg-gray-100 text-gray-800';
                              
                              return (
                                <div key={adjustment.id} className="p-3 border rounded-lg">
                                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                    <div className="flex items-start gap-3 flex-1">
                                      <Badge className={categoryColor}>
                                        {adjustment.category === 'all' ? 'All Products' : adjustment.category}
                                      </Badge>
                                      <div className="space-y-1 flex-1">
                                        <div className="text-sm font-medium">
                                          {adjustment.adjustmentType === 'percentage' 
                                            ? `${(adjustment.adjustmentValue * 100).toFixed(0)}% of normal shelf life`
                                            : `${adjustment.adjustmentValue > 0 ? '+' : ''}${adjustment.adjustmentValue} hours`
                                          }
                                        </div>
                                        {adjustment.notes && (
                                          <div className="text-xs text-gray-500">{adjustment.notes}</div>
                                        )}
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2 w-full sm:w-auto">
                                      <div className="flex items-center space-x-2 flex-1 sm:flex-none">
                                        <Switch 
                                          checked={adjustment.isActive}
                                          onCheckedChange={(checked) => 
                                            updateSeasonalAdjustment(adjustment.id, { isActive: checked })
                                          }
                                        />
                                        <span className="text-xs text-gray-600 sm:hidden">
                                          {adjustment.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                      </div>
                                      <div className="flex gap-2">
                                        <Button 
                                          size="sm" 
                                          variant="ghost"
                                          className="h-8 w-8 p-0"
                                          onClick={() => {
                                            setSelectedSeasonalAdjustment(adjustment);
                                            setSeasonalAdjustmentForm({
                                              season: adjustment.season,
                                              category: adjustment.category,
                                              adjustmentType: adjustment.adjustmentType,
                                              adjustmentValue: adjustment.adjustmentValue,
                                              notes: adjustment.notes || ''
                                            });
                                            setShowAddSeasonalAdjustmentDialog(true);
                                          }}
                                        >
                                          <Edit className="h-4 w-4" />
                                        </Button>
                                        <Button 
                                          size="sm" 
                                          variant="ghost"
                                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                                          onClick={() => deleteSeasonalAdjustment(adjustment.id)}
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          }
                          
                          {seasonalSettings.adjustments.filter(adj => adj.season === seasonalSettings.currentSeason).length === 0 && (
                            <div className="text-center py-8 text-gray-500">
                              <CalendarIcon className="h-8 w-8 mx-auto mb-2 opacity-50" />
                              <div>No adjustments configured for {seasonalSettings.currentSeason}</div>
                              <div className="text-sm">Click "Add Adjustment" to create seasonal modifications</div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Preview Impact */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Adjustment Preview</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                          {['SCRAMBLED EGGS', 'CAESAR SALAD MIX', 'BEEF PATTIES 4:1'].map(productName => {
                            const product = products.find(p => p.name === productName);
                            if (!product) return null;
                            
                            const originalHours = product.defaultShelfLifeHours;
                            const adjustedHours = getAdjustedShelfLife(product);
                            const changeValue = ((adjustedHours - originalHours) / originalHours * 100);
                            const changePercent = changeValue.toFixed(0);
                            
                            return (
                              <div key={productName} className="p-3 border rounded-lg">
                                <div className="font-medium text-xs mb-2 line-clamp-2">{productName}</div>
                                <div className="space-y-1">
                                  <div className="text-gray-600 text-xs">Original: {originalHours}h</div>
                                  <div className={`font-medium text-xs ${
                                    adjustedHours < originalHours ? 'text-red-600' : 
                                    adjustedHours > originalHours ? 'text-green-600' : 'text-gray-600'
                                  }`}>
                                    Adjusted: {adjustedHours}h ({changeValue > 0 ? '+' : ''}{changePercent}%)
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* New Message Dialog */}
      <Dialog open={showMessageDialog} onOpenChange={setShowMessageDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Send Message</DialogTitle>
            <DialogDescription>
              Send a message to users in the system
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Recipient</Label>
              <Select value={messageForm.toUserId} onValueChange={(value) => {
                setMessageForm(prev => ({ ...prev, toUserId: value, toRole: undefined }));
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a user" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="broadcast-rm">All Restaurant Managers</SelectItem>
                  {currentUser.role === 'RFS' && (
                    <SelectItem value="broadcast-oc">All Operations Consultants</SelectItem>
                  )}
                  <Separator />
                  {users
                    .filter(u => u.id !== currentUser.id)
                    .map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name} ({user.role})
                      </SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Subject</Label>
              <Input
                value={messageForm.subject}
                onChange={(e) => setMessageForm(prev => ({ ...prev, subject: e.target.value }))}
                placeholder="Enter message subject"
              />
            </div>

            <div className="space-y-2">
              <Label>Message</Label>
              <Textarea
                value={messageForm.content}
                onChange={(e) => setMessageForm(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Enter your message"
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMessageDialog(false)}>
              Cancel
            </Button>
            <Button onClick={sendMessage} disabled={!messageForm.subject || !messageForm.content}>
              <Send className="h-4 w-4 mr-2" />
              Send Message
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create User Dialog */}
      <Dialog open={showCreateUserDialog} onOpenChange={setShowCreateUserDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
            <DialogDescription>
              Add a new user to the system
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input
                value={newUserForm.name}
                onChange={(e) => setNewUserForm(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter full name"
              />
            </div>

            <div className="space-y-2">
              <Label>Username</Label>
              <Input
                value={newUserForm.username}
                onChange={(e) => setNewUserForm(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter username"
              />
            </div>

            <div className="space-y-2">
              <Label>Password</Label>
              <Input
                type="password"
                value={newUserForm.password}
                onChange={(e) => setNewUserForm(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter password"
              />
            </div>

            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={newUserForm.role} onValueChange={(value) => {
                setNewUserForm(prev => ({ ...prev, role: value as UserRole, regionId: '', restaurantId: '' }));
              }}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currentUser.role === 'RFS' && (
                    <SelectItem value="OC">Operations Consultant (OC)</SelectItem>
                  )}
                  <SelectItem value="RM">Restaurant Manager (RM)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {newUserForm.role === 'OC' && (
              <div className="space-y-2">
                <Label>Region</Label>
                <Select value={newUserForm.regionId} onValueChange={(value) => {
                  setNewUserForm(prev => ({ ...prev, regionId: value }));
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map(region => (
                      <SelectItem key={region.id} value={region.id}>
                        {region.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {newUserForm.role === 'RM' && (
              <div className="space-y-2">
                <Label>Restaurant</Label>
                <Select value={newUserForm.restaurantId} onValueChange={(value) => {
                  const restaurant = restaurants.find(r => r.id === value);
                  setNewUserForm(prev => ({ 
                    ...prev, 
                    restaurantId: value,
                    regionId: restaurant?.regionId || ''
                  }));
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select restaurant" />
                  </SelectTrigger>
                  <SelectContent>
                    {restaurants
                      .filter(r => currentUser.role === 'RFS' || r.regionId === currentUser.regionId)
                      .map(restaurant => (
                        <SelectItem key={restaurant.id} value={restaurant.id}>
                          {restaurant.name}
                        </SelectItem>
                      ))
                    }
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateUserDialog(false)}>
              Cancel
            </Button>
            <Button onClick={createUser} disabled={!newUserForm.name || !newUserForm.username || !newUserForm.password}>
              Create User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Product Dialog */}
      <Dialog open={showEditProductDialog} onOpenChange={setShowEditProductDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Product: {selectedProduct?.name}</DialogTitle>
            <DialogDescription>
              Modify product settings and shelf life times
            </DialogDescription>
          </DialogHeader>
          
          {selectedProduct ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Product Name</Label>
                <Input
                  defaultValue={selectedProduct.name}
                  readOnly
                  className="bg-muted"
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-lg font-semibold text-primary">Shelf Life (Hours)</Label>
                <Input
                  type="number"
                  min="0.5"
                  step="0.5"
                  defaultValue={selectedProduct.defaultShelfLifeHours}
                  className="text-lg font-medium border-2 border-primary/50"
                  id="shelfLifeInput"
                />
                <div className="bg-blue-50 p-3 rounded">
                  <p className="font-medium text-blue-800">Current: {selectedProduct.defaultShelfLifeHours} hours</p>
                  <p className="text-sm text-blue-600">
                    {selectedProduct.isDailyProduct 
                      ? `Daily product - auto-renews every ${selectedProduct.defaultShelfLifeHours} hours`
                      : `Regular product - expires ${selectedProduct.defaultShelfLifeHours} hours after receiving`
                    }
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Category</Label>
                <Input
                  defaultValue={selectedProduct.category}
                  readOnly
                  className="bg-muted capitalize"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea
                  defaultValue={selectedProduct.notes || ''}
                  placeholder="Food safety guidelines, storage requirements..."
                  rows={3}
                  id="notesInput"
                />
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setShowEditProductDialog(false);
                  setSelectedProduct(null);
                }}>
                  Cancel
                </Button>
                <Button onClick={() => {
                  try {
                    const shelfLifeInput = document.getElementById('shelfLifeInput') as HTMLInputElement;
                    const notesInput = document.getElementById('notesInput') as HTMLTextAreaElement;
                    
                    const newShelfLife = parseFloat(shelfLifeInput?.value || '24');
                    const newNotes = notesInput?.value || '';
                    
                    const updatedProduct = {
                      ...selectedProduct,
                      defaultShelfLifeHours: newShelfLife,
                      notes: newNotes || undefined
                    };
                    
                    setProducts(prev => prev.map(p => 
                      p.id === selectedProduct.id ? updatedProduct : p
                    ));
                    
                    setShowEditProductDialog(false);
                    setSelectedProduct(null);
                    
                    alert(`Product updated successfully!\nNew shelf life: ${newShelfLife} hours`);
                  } catch (error) {
                    console.error('Error updating product:', error);
                    alert('Error updating product. Please try again.');
                  }
                }}>
                  Save Changes
                </Button>
              </DialogFooter>
            </div>
          ) : (
            <div className="p-4 text-center">
              <p>No product selected</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Product Dialog */}
      <Dialog open={showAddProductDialog} onOpenChange={setShowAddProductDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
            <DialogDescription>
              Add a new product to the catalog
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            <div className="space-y-2">
              <Label>Product Name</Label>
              <Input
                value={newProductForm.name}
                onChange={(e) => setNewProductForm(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter product name (will be converted to UPPERCASE)"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={newProductForm.category} onValueChange={(value) => {
                  setNewProductForm(prev => ({ ...prev, category: value as ProductCategory }));
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meat">Meat</SelectItem>
                    <SelectItem value="chicken">Chicken</SelectItem>
                    <SelectItem value="bakery">Bakery</SelectItem>
                    <SelectItem value="vegetables">Vegetables</SelectItem>
                    <SelectItem value="beverages">Beverages</SelectItem>
                    <SelectItem value="condiments">Condiments</SelectItem>
                    <SelectItem value="frozen">Frozen</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="mccafe">McCafe</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Color</Label>
                <Select value={newProductForm.color} onValueChange={(value) => {
                  setNewProductForm(prev => ({ ...prev, color: value }));
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bg-red-500">Red</SelectItem>
                    <SelectItem value="bg-orange-500">Orange</SelectItem>
                    <SelectItem value="bg-yellow-500">Yellow</SelectItem>
                    <SelectItem value="bg-green-500">Green</SelectItem>
                    <SelectItem value="bg-blue-500">Blue</SelectItem>
                    <SelectItem value="bg-purple-500">Purple</SelectItem>
                    <SelectItem value="bg-pink-500">Pink</SelectItem>
                    <SelectItem value="bg-amber-500">Amber</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Shelf Life (Hours)</Label>
                <Input
                  type="number"
                  min="1"
                  value={newProductForm.defaultShelfLifeHours}
                  onChange={(e) => setNewProductForm(prev => ({ 
                    ...prev, 
                    defaultShelfLifeHours: parseInt(e.target.value) || 24 
                  }))}
                />
              </div>

              <div className="space-y-2">
                <Label>Label Size</Label>
                <Select value={newProductForm.labelSize} onValueChange={(value) => {
                  setNewProductForm(prev => ({ ...prev, labelSize: value as 'small' | 'medium' | 'large' }));
                }}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small (2"×1")</SelectItem>
                    <SelectItem value="medium">Medium (3"×2")</SelectItem>
                    <SelectItem value="large">Large (4"×3")</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch 
                checked={newProductForm.isDailyProduct}
                onCheckedChange={(checked) => setNewProductForm(prev => ({ ...prev, isDailyProduct: checked }))}
              />
              <Label>Daily Product (Auto-renewal)</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch 
                checked={newProductForm.requiresThawing}
                onCheckedChange={(checked) => setNewProductForm(prev => ({ ...prev, requiresThawing: checked }))}
              />
              <Label>Requires Thawing</Label>
            </div>

            {newProductForm.requiresThawing && (
              <div className="space-y-2">
                <Label>Thaw Time (Hours)</Label>
                <Input
                  type="number"
                  min="0"
                  value={newProductForm.thawTimeHours}
                  onChange={(e) => setNewProductForm(prev => ({ 
                    ...prev, 
                    thawTimeHours: parseInt(e.target.value) || 0 
                  }))}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label>Notes (Optional)</Label>
              <Textarea
                value={newProductForm.notes}
                onChange={(e) => setNewProductForm(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Additional notes about this product"
                rows={2}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddProductDialog(false)}>
              Cancel
            </Button>
            <Button onClick={addProduct} disabled={!newProductForm.name}>
              Add Product
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Inventory Dialog */}
      <Dialog open={showAddInventoryDialog} onOpenChange={setShowAddInventoryDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Inventory Item</DialogTitle>
            <DialogDescription>
              Add a new item to your restaurant's inventory
            </DialogDescription>
          </DialogHeader>
          
          <AddInventoryForm 
            products={products.filter(p => p.isActive)}
            onSubmit={addInventoryItem}
            onCancel={() => setShowAddInventoryDialog(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Seasonal Adjustment Dialog */}
      <Dialog open={showAddSeasonalAdjustmentDialog} onOpenChange={setShowAddSeasonalAdjustmentDialog}>
        <DialogContent className="sm:max-w-md max-w-[95vw] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">
              {selectedSeasonalAdjustment ? 'Edit Seasonal Adjustment' : 'Add Seasonal Adjustment'}
            </DialogTitle>
            <DialogDescription className="text-sm">
              Configure automatic shelf life adjustments based on seasonal temperatures
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Season</Label>
                <Select 
                  value={seasonalAdjustmentForm.season} 
                  onValueChange={(value: Season) => 
                    setSeasonalAdjustmentForm(prev => ({ ...prev, season: value }))
                  }
                >
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summer">Summer</SelectItem>
                    <SelectItem value="winter">Winter</SelectItem>
                    <SelectItem value="spring">Spring</SelectItem>
                    <SelectItem value="autumn">Autumn</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium">Product Category</Label>
                <Select 
                  value={seasonalAdjustmentForm.category} 
                  onValueChange={(value: ProductCategory | 'all') => 
                    setSeasonalAdjustmentForm(prev => ({ ...prev, category: value }))
                  }
                >
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Products</SelectItem>
                    <SelectItem value="meat">Meat</SelectItem>
                    <SelectItem value="chicken">Chicken</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="vegetables">Vegetables</SelectItem>
                    <SelectItem value="bakery">Bakery</SelectItem>
                    <SelectItem value="beverages">Beverages</SelectItem>
                    <SelectItem value="condiments">Condiments</SelectItem>
                    <SelectItem value="frozen">Frozen</SelectItem>
                    <SelectItem value="mccafe">McCafe</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Adjustment Type</Label>
                <Select 
                  value={seasonalAdjustmentForm.adjustmentType} 
                  onValueChange={(value: 'percentage' | 'hours') => 
                    setSeasonalAdjustmentForm(prev => ({ ...prev, adjustmentType: value }))
                  }
                >
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage</SelectItem>
                    <SelectItem value="hours">Hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  {seasonalAdjustmentForm.adjustmentType === 'percentage' 
                    ? 'Percentage (1.0 = 100%)' 
                    : 'Hours Adjustment'
                  }
                </Label>
                <Input
                  type="number"
                  step={seasonalAdjustmentForm.adjustmentType === 'percentage' ? '0.05' : '1'}
                  min={seasonalAdjustmentForm.adjustmentType === 'percentage' ? '0.1' : '-24'}
                  max={seasonalAdjustmentForm.adjustmentType === 'percentage' ? '2.0' : '24'}
                  value={seasonalAdjustmentForm.adjustmentValue}
                  onChange={(e) => 
                    setSeasonalAdjustmentForm(prev => ({ 
                      ...prev, 
                      adjustmentValue: parseFloat(e.target.value) || 1.0 
                    }))
                  }
                  placeholder={seasonalAdjustmentForm.adjustmentType === 'percentage' ? '0.8 (80%)' : '-2 hours'}
                  className="h-10"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium">Notes (Optional)</Label>
              <Textarea
                value={seasonalAdjustmentForm.notes}
                onChange={(e) => 
                  setSeasonalAdjustmentForm(prev => ({ ...prev, notes: e.target.value }))
                }
                placeholder="Reason for this adjustment (e.g., 'Higher temperatures require shorter shelf life')" 
                rows={3}
                className="text-sm"
              />
            </div>
            
            {/* Preview */}
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="text-sm font-medium mb-2">Preview:</div>
              <div className="text-xs text-gray-600">
                {seasonalAdjustmentForm.adjustmentType === 'percentage' 
                  ? `Products will have ${(seasonalAdjustmentForm.adjustmentValue * 100).toFixed(0)}% of their normal shelf life`
                  : `Products will have ${seasonalAdjustmentForm.adjustmentValue > 0 ? '+' : ''}${seasonalAdjustmentForm.adjustmentValue} hours ${seasonalAdjustmentForm.adjustmentValue > 0 ? 'added to' : 'removed from'} their normal shelf life`
                }
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0">
            <Button 
              variant="outline" 
              className="w-full sm:w-auto order-2 sm:order-1"
              onClick={() => {
                setShowAddSeasonalAdjustmentDialog(false);
                setSelectedSeasonalAdjustment(null);
                setSeasonalAdjustmentForm({
                  season: 'summer',
                  category: 'all',
                  adjustmentType: 'percentage',
                  adjustmentValue: 1.0,
                  notes: ''
                });
              }}
            >
              Cancel
            </Button>
            <Button 
              className="w-full sm:w-auto order-1 sm:order-2"
              onClick={() => {
                if (selectedSeasonalAdjustment) {
                  // Update existing adjustment
                  updateSeasonalAdjustment(selectedSeasonalAdjustment.id, {
                    season: seasonalAdjustmentForm.season,
                    category: seasonalAdjustmentForm.category,
                    adjustmentType: seasonalAdjustmentForm.adjustmentType,
                    adjustmentValue: seasonalAdjustmentForm.adjustmentValue,
                    notes: seasonalAdjustmentForm.notes
                  });
                } else {
                  // Add new adjustment
                  addSeasonalAdjustment({
                    season: seasonalAdjustmentForm.season,
                    category: seasonalAdjustmentForm.category,
                    adjustmentType: seasonalAdjustmentForm.adjustmentType,
                    adjustmentValue: seasonalAdjustmentForm.adjustmentValue,
                    isActive: true,
                    notes: seasonalAdjustmentForm.notes
                  });
                }
                
                setShowAddSeasonalAdjustmentDialog(false);
                setSelectedSeasonalAdjustment(null);
                setSeasonalAdjustmentForm({
                  season: 'summer',
                  category: 'all',
                  adjustmentType: 'percentage',
                  adjustmentValue: 1.0,
                  notes: ''
                });
              }}
            >
              {selectedSeasonalAdjustment ? 'Update' : 'Add'} Adjustment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Other dialogs will be added here... */}
    </div>
  );
}

// Add Inventory Form Component (same as before)
function AddInventoryForm({ products, onSubmit, onCancel }: {
  products: Product[];
  onSubmit: (data: Partial<InventoryItem>) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState({
    productId: '',
    quantity: 1,
    batchNumber: ''
  });

  const handleSubmit = () => {
    if (!formData.productId) return;
    
    onSubmit({
      productId: formData.productId,
      quantity: formData.quantity,
      batchNumber: formData.batchNumber || undefined,
      receivedDate: new Date()
    });
    
    setFormData({ productId: '', quantity: 1, batchNumber: '' });
  };

  const selectedProduct = products.find(p => p.id === formData.productId);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="product">Product</Label>
        <Select value={formData.productId} onValueChange={(value) => setFormData(prev => ({ ...prev, productId: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Select a product" />
          </SelectTrigger>
          <SelectContent>
            {products.map(product => (
              <SelectItem key={product.id} value={product.id}>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${product.color}`} />
                  <span>{product.name}</span>
                  <Badge variant="outline" className="ml-2">{product.category}</Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedProduct && (
        <div className="p-3 bg-muted/50 rounded">
          <p className="text-sm font-medium">Product Information:</p>
          <p className="text-xs text-muted-foreground">Shelf Life: {selectedProduct.defaultShelfLifeHours} hours</p>
          {selectedProduct.requiresThawing && (
            <p className="text-xs text-muted-foreground">Requires thawing: {selectedProduct.thawTimeHours} hours</p>
          )}
          {selectedProduct.isDailyProduct && (
            <p className="text-xs text-yellow-600">Daily Product - Auto-renewal enabled</p>
          )}
          {selectedProduct.notes && (
            <p className="text-xs text-muted-foreground">Notes: {selectedProduct.notes}</p>
          )}
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="quantity">Quantity</Label>
        <Input
          id="quantity"
          type="number"
          min="1"
          value={formData.quantity}
          onChange={(e) => setFormData(prev => ({ ...prev, quantity: parseInt(e.target.value) || 1 }))}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="batch">Batch Number (Optional)</Label>
        <Input
          id="batch"
          type="text"
          value={formData.batchNumber}
          onChange={(e) => setFormData(prev => ({ ...prev, batchNumber: e.target.value }))}
          placeholder="Enter batch number"
        />
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={!formData.productId}>
          Add Item
        </Button>
      </DialogFooter>
    </div>
  );
}