/**
 * @fileOverview Cross
 */

export var Cell = function Cell(_props) {
  return null;
};
Cell.displayName = 'Cell';