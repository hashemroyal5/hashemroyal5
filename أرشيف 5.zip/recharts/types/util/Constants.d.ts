export declare const COLOR_PANEL: string[];
