export declare function shallowEqual(a: any, b: any): boolean;
