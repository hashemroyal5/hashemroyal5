export declare function safeEvaluateExpression(expression: string): string;
export declare function reduceCSSCalc(expression: string): string;
