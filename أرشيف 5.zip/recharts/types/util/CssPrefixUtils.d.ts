export declare const generatePrefixStyle: (name: string, value: string) => Record<string, string>;
