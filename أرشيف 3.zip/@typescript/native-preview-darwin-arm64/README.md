# `@typescript/native-preview-darwin-arm64`

This package provides darwin-arm64 support for [@typescript/native-preview-darwin-arm64](https://www.npmjs.com/package/@typescript/native-preview-darwin-arm64).
