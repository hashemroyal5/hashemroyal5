import { AwsCrc32 } from "@aws-crypto/crc32";
export declare const getCrc32ChecksumAlgorithmFunction: () => typeof AwsCrc32;
