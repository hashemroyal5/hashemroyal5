/**
 * Returns true if the given value is a streaming response.
 */
export declare const isStreaming: (body: unknown) => boolean;
