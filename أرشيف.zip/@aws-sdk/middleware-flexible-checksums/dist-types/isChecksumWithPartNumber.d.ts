export declare const isChecksumWithPartNumber: (checksum: string) => boolean;
