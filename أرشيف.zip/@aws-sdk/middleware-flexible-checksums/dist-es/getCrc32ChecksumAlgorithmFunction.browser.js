import { AwsCrc32 } from "@aws-crypto/crc32";
export const getCrc32ChecksumAlgorithmFunction = () => AwsCrc32;
