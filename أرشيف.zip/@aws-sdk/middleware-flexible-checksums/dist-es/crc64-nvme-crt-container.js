export const crc64NvmeCrtContainer = {
    CrtCrc64Nvme: null,
};
