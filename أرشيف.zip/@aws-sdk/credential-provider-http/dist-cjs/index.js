"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromHttp = void 0;
var fromHttp_1 = require("./fromHttp/fromHttp");
Object.defineProperty(exports, "fromHttp", { enumerable: true, get: function () { return fromHttp_1.fromHttp; } });
