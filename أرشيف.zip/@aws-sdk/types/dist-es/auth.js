export { HttpAuthLocation } from "@smithy/types";
