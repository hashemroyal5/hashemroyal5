export { EndpointURLScheme, } from "@smithy/types";
