/**
 * @internal
 */
export * from "./XmlNode";
/**
 * @internal
 */
export * from "./XmlText";
