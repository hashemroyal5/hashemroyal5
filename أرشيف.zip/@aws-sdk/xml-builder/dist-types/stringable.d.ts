/**
 * @internal
 */
export interface Stringable {
    toString(): string;
}
