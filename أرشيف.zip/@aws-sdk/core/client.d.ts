/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
declare module "@aws-sdk/core/client" {
  export * from "@aws-sdk/core/dist-types/submodules/client/index.d";
}
