import { TokenIdentityProvider } from "@aws-sdk/types";
import { FromSsoInit } from "./fromSso";
export declare const nodeProvider: (
  init?: FromSsoInit
) => TokenIdentityProvider;
