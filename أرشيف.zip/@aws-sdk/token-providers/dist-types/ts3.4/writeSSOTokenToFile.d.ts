import { SSOToken } from "@smithy/shared-ini-file-loader";
export declare const writeSSOTokenToFile: (
  id: string,
  ssoToken: SSOToken
) => Promise<void>;
