import { TokenIdentity } from "@aws-sdk/types";
export declare const validateTokenExpiry: (token: TokenIdentity) => void;
