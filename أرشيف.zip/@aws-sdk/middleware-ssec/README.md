# @aws-sdk/middleware-ssec

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/middleware-ssec/latest.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-ssec)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/middleware-ssec.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-ssec)
