import { GetRoleCredentialsCommand, SSOClient } from "@aws-sdk/client-sso";
export { GetRoleCredentialsCommand, SSOClient };
