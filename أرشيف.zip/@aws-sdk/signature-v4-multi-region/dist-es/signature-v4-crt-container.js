export const signatureV4CrtContainer = {
    CrtSignerV4: null,
};
