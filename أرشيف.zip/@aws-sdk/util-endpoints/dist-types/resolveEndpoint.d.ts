export { resolveEndpoint } from "@smithy/util-endpoints";
