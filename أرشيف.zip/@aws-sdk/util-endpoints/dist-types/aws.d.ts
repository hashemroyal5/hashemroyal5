import { EndpointFunctions } from "@smithy/util-endpoints";
export declare const awsEndpointFunctions: EndpointFunctions;
