export declare const crtAvailability: {
  isCrtAvailable: boolean;
};
