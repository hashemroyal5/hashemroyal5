export const crtAvailability = {
    isCrtAvailable: false,
};
