/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
declare module "@aws-sdk/nested-clients/sts" {
  export * from "@aws-sdk/nested-clients/dist-types/submodules/sts/index.d";
}
