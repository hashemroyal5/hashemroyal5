/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
declare module "@aws-sdk/nested-clients/sso-oidc" {
  export * from "@aws-sdk/nested-clients/dist-types/submodules/sso-oidc/index.d";
}
