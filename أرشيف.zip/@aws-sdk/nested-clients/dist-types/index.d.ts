/**
 * This package exports nothing at the root.
 * Use submodules e.g. \@aws-sdk/nested-clients/client-sts.
 *
 * @internal
 */
export {};
