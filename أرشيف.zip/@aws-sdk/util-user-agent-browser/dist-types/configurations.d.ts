/**
 * @internal
 */
export interface DefaultUserAgentOptions {
    serviceId?: string;
    clientVersion: string;
}
