export function resolveLocationConstraintConfig(input) {
    return input;
}
